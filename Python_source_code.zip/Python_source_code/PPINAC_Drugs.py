import sys


def main():
    f2 = open("Drugs_ppi_alignment_human_mouse_funct_v1.tab", "w+")
    print("----------------PPINAC--------------")
    GOT_covid19_file = 'data/CTD2/CTD_C000657245_diseases_20201023063932.tsv'
    GOT_covid19_List = {}
    with open(GOT_covid19_file) as f:
        f.next()
        for line in f:
            it = line.strip().split()
            got_id = str(it[1])
            gotDesc_covid19 = str(it[0])
            if got_id not in GOT_covid19_List:
                GOT_covid19_List[got_id] = set()
            GOT_covid19_List[got_id].add(gotDesc_covid19)

    GOT_goa_human_file = 'data/goa/goa_human.tab'
    GOT_goa_human_List = {}
    with open(GOT_goa_human_file) as f:
        f.next()
        for line in f:
            it = line.strip().split('\t')
            got_id = str(it[1])

            gotDesc = str(it[4])
            if (str(it[7])=='P') or (str(it[8])=='P'):
                if got_id not in GOT_goa_human_List:
                    GOT_goa_human_List[got_id] = set()
                GOT_goa_human_List[got_id].add(gotDesc)

    GOT_goa_mouse_file = 'data/goa/goa_mouse.tab'
    GOT_goa_mouse_List = {}
    with open(GOT_goa_mouse_file) as f:
        f.next()
        for line in f:
            it = line.strip().split('\t')
            got_id = str(it[1])
            gotDesc = str(it[4])
            if (str(it[7]) == 'P') or (str(it[8]) == 'P'):
                if got_id not in GOT_goa_mouse_List:
                    GOT_goa_mouse_List[got_id] = set()
                GOT_goa_mouse_List[got_id].add(gotDesc)
    ############################################
    genes_covid19_file = 'data/CTD2/CTD_C000657245_genes_20201023063913.tsv'
    Gene_covid19_List = {}
    with open(genes_covid19_file) as f:
        f.next()
        for line in f:
            it = line.strip().split()
            disease_id = ''
            gene_id = str(it[0])
            disease_covid19 = str(it[3])
            if gene_id not in Gene_covid19_List:
                Gene_covid19_List[gene_id] = set()
            Gene_covid19_List[gene_id].add(disease_covid19)

    genes_covid19_file = 'data/CTD2/CTD_C000657245_genes_20201023063913.tsv'
    Gene_covid19_drug_List = {}
    cmpti=0
    with open(genes_covid19_file) as f:
        f.next()
        for line in f:
            if (cmpti<17):
                it = line.strip().split('\t')
                disease_id = ''
                gene_id = str(it[0])
                drug_covid19 = str(it[5])
                drlist=drug_covid19.strip().split('|')
                if gene_id not in Gene_covid19_drug_List:
                    Gene_covid19_drug_List[gene_id] = set()
                for x in drlist:
                    Gene_covid19_drug_List[gene_id].add(x)
                cmpti=cmpti+1
            else:
                it = line.strip().split('\t')
                disease_id = ''
                gene_id = str(it[0])
                if(gene_id!='BSG'):
                    drug_covid19 = str(it[5])
                    drlist = drug_covid19.strip().split('|')
                    if gene_id not in Gene_covid19_drug_List:
                        Gene_covid19_drug_List[gene_id] = set()
                    for x in drlist:
                        Gene_covid19_drug_List[gene_id].add(x)




    ####################Drug Prediction from methods 2#####################"

    drug_protID_file = 'data/data_prediction/drugbank_all_target_uniprot_links.txt'
    matrix_drug_prot_info_List = {}
    matrix_ligne_drug_mapping_List = {}
    with open(drug_protID_file) as f:
        f.next()
        for line in f:
            it = line.strip().split('\t')
            drug_id = str(it[0])
            prot_id = str(it[3])
            if drug_id not in matrix_drug_prot_info_List:
                matrix_drug_prot_info_List[drug_id] = set()
            matrix_drug_prot_info_List[drug_id].add(prot_id)

        ########################################################################
        human_gene_file = 'data/data_prediction/uniprot_human_filtred.tab'
        human_gene_info_List = {}
        with open(human_gene_file) as f:
            f.next()
            for line in f:
                it = line.strip().split('\t')
                entry_id = str(it[1])
                try:
                    geneh_id = str(it[2])
                    if entry_id not in human_gene_info_List:
                        human_gene_info_List[entry_id] = set()

                    human_gene_info_List[entry_id].add(geneh_id)
                except:
                    pass
        ###################For the drug prediction###################
        human_gene_drug_List = {}
        with open(human_gene_file) as fdr:
            fdr.next()
            for line in fdr:
                it = line.strip().split('\t')
                try:
                    g_id = str(it[2])
                    pdr_id = str(it[0])
                    if g_id not in human_gene_drug_List:
                        human_gene_drug_List[g_id] = set()

                    human_gene_drug_List[g_id].add(pdr_id)
                except:
                    pass

        human_prot_gene_drug_List = {}
        with open(human_gene_file) as fdr2:
            fdr2.next()
            for line in fdr2:
                it = line.strip().split('\t')
                try:
                    g_id = str(it[2])
                    pdr_id = str(it[0])
                    if pdr_id not in human_prot_gene_drug_List:
                        human_prot_gene_drug_List[pdr_id] = set()
                    human_prot_gene_drug_List[pdr_id].add(g_id)
                except:
                    pass
        ###################parsing drugbank target uniprot##########################

        drug_bank_file = 'data/data_prediction/drugbank_all_target_uniprot_links.txt'
        drug_bank_List = {}
        drug_bank_ID_List = {}
        with open(drug_bank_file) as drbk:
            drbk.next()
            for line in drbk:
                it = line.strip().split('\t')

                try:
                    target_id = str(it[3])
                    info_drug = str(it[0]) + ' ' + str(it[1])
                    if target_id not in drug_bank_List:
                        drug_bank_List[target_id] = set()

                    drug_bank_List[target_id].add(info_drug)
                    if target_id not in drug_bank_ID_List:
                        drug_bank_ID_List[target_id] = set()

                    drug_bank_ID_List[target_id].add(str(it[0]))
                except:
                    pass


        ###########################################################################
        protein_info_file = 'data/data_prediction/9606.protein.info.v11.0.txt'
        protein_info_List = {}
        with open(protein_info_file) as f:
            f.next()
            for line in f:
                it = line.strip().split()
                p_id = str(it[0])
                if p_id not in protein_info_List:
                    protein_info_List[p_id] = set()

                info_id = str(it[1])
                protein_info_List[p_id].add(info_id)

        # for i, row in enumerate(protein_info_List):
        #     annots = {}
        #     p_id = row
        #     info_id = protein_info_List[p_id]
        #     print("%s %s\n" % (p_id, info_id))
        #########################################################"


        ppialignment_file = 'data/data_prediction/ppinac_alignment_funct.txt'
        ppi_align_List = {}
        with open(ppialignment_file) as f:
            for line in f:
                it = line.strip().split()
                mm_id = str(it[0])
                hs_id = str(it[1])
                if hs_id not in ppi_align_List:
                    ppi_align_List[hs_id] = set()

                ppi_align_List[hs_id].add(mm_id)

        f2.write("%s %s %s %s %s %s %s" % ("Human Protein", "Human Gene","Mouse Protein", "DrugBank ID  (Human)", " CTD Drug (Human)", "GOT Human", "GOT Mouse"))
        for i, row in enumerate(ppi_align_List):
                hs_id = row
                mm_ids = ppi_align_List[hs_id]
                if hs_id in human_prot_gene_drug_List:
                    hs_set = human_prot_gene_drug_List[hs_id]
                    for mm_id in mm_ids:
                        mm_prot=mm_id
                    for hs in hs_set:
                        hs_gene = hs
                    f2.write("%s %s %s %s %s %s" % (hs_id, '&', hs_gene, '&', mm_id, "&") )
                    if hs_id in drug_bank_ID_List:
                        drug_set = drug_bank_ID_List[hs_id]
                        for dr in drug_set:
                            drbank_prot = dr
                            f2.write("%s " % (drbank_prot))
                    else:
                        drbank_prot = "N.A"
                        f2.write("%s " % (drbank_prot))
                    f2.write("%s " % ('&'))
                    if hs_gene in Gene_covid19_drug_List:
                        drugCTD_set = Gene_covid19_drug_List[hs_gene]
                        for dr in drugCTD_set:
                            drbankCTD_prot = dr
                            f2.write("%s %s" % (drbankCTD_prot, "|"))
                    else:
                        drbankCTD_prot = "N.A"
                        f2.write("%s " % (drbankCTD_prot))
                    f2.write("%s " % ('&'))
                    if hs_id in GOT_goa_human_List:
                        gotgoa_set = GOT_goa_human_List[hs_id]
                        # if ('Q5MIZ7' == hs_id):
                        #     print(gotgoa_set)
                        for gt in gotgoa_set:
                            gt_prot = gt
                            if (gt_prot in GOT_covid19_List):
                                f2.write("%s %s %s %s" % ("*",gt_prot,'*', "|"))
                            else:
                                f2.write("%s %s" % (gt_prot, "|"))

                    else:
                        gt_prot = "N.A"
                        f2.write("%s " % (gt_prot))
                    f2.write("%s " % ('&'))
                    if mm_id in GOT_goa_mouse_List:
                        gotgoa_set = GOT_goa_mouse_List[mm_id]
                        for gt in gotgoa_set:
                            gt_prot = gt
                            if (gt_prot in GOT_covid19_List):
                                f2.write("%s %s %s %s" % ("*", gt_prot, '*', "|"))
                            else:
                                f2.write("%s %s" % (gt_prot, "|"))

                    else:
                        gt_prot = "N.A"
                        f2.write("%s " % (gt_prot))
                    str1="\\"
                    str2 = "\\"

                    f2.write("%s%s"% (str1, str2))
                    f2.write("\n")






        ##########################################################"



if __name__ == '__main__':
    main()
