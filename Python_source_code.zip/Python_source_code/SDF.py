import itertools
import gzip

import pandas
from rdkit.Chem import AllChem
import rdkit.DataStructs



if __name__=="__main__":
    REF_covid19_file = 'data/CTD_C000657245_references_20201023115438.tsv'
    REF_covid19_List = {}
    with open(REF_covid19_file) as f:
        f.next()
        for line in f:
            it = line.strip().split('\t')
            pubmid_id = str(it[0])
            drug_covid19 = str(it[6])
            print("%s%s%s" % (pubmid_id,'&', drug_covid19))
    # Read SDF File
    supplier = rdkit.Chem.SDMolSupplier('SDF/structures.sdf')
    molecules = [mol for mol in supplier if mol is not None]
    print(len(molecules))
    # Calculate fingerprints
    fingerprints = dict()
    for mol in molecules:
        drugbank_id = mol.GetProp('DATABASE_ID')
        fingerprint = rdkit.Chem.AllChem.GetMorganFingerprint(mol, 2)
        fingerprints[drugbank_id] = fingerprint
    # Calculate pairwise compound similarities
    similarity_rows = list()
    for (id0, fp0), (id1, fp1) in itertools.combinations(fingerprints.items(), 2):
        similarity = rdkit.DataStructs.DiceSimilarity(fp0, fp1)
        similarity = round(similarity, 4)
        similarity_rows.append([id0, id1, similarity])
    # Create a DataFrame of pairwise similarities
    similarity_df = pandas.DataFrame(similarity_rows, columns=['compound0', 'compound1', 'similarity'])
    for index, row in similarity_df.iterrows():
        if(row['compound0']=='DB12781')and(row['compound1']=='DB12782'):
            print(row['compound0'], row['compound1'], row['similarity'])


    with gzip.open('data/similarity.tsv.gz', 'w') as write_file:
        similarity_df.to_csv(write_file, sep='\t', index=False)
    print(similarity_df.head())





