#include "Alignment.h"
#include <fstream>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;
string filename1("semanticSimilarities.txt");
ofstream filesemanticfile(filename1.c_str());
//constructor
//finds the smaller network and the maximum degree of the input networks
//Inputs are two files of networks net1 and net2
Alignment::Alignment( Network net1, Network net2)
{
	//compare networks to find the biggest one
    if( net1.size > net2.size )
	{
		reverse = true;
		network1 = net2;
		network2 = net1;
	}
	else
	{
		reverse = false;
		network1 = net1;
		network2 = net2;
	}
   // cout<<network1.name<<endl;
    //cout<<network2.name<<endl;
    
	//maximum degree of the network
    if(network1.maxDeg > network2.maxDeg)
		maxDeg = network1.maxDeg;
	else
		maxDeg = network2.maxDeg;

	similarity = new float*[network1.size];

	for(int i=0; i<network1.size; i++)
	{
		similarity[i] = new float[network2.size];
	}
}

// This function calculates the similarity between node1 in the first network and node2 in the second network given the similarity of their neighbors
float Alignment::computeSimilarity(int node1, int node2)
{
	bool *al;
	float *sim;
	int last;

	float tempS = 0;

	int deg1 = network1.deg[node1];
	int deg2 = network2.deg[node2];
    
    // We find a good alignment of neighbors of node1 and node2 heuristicly and then the similarity of node1 and node2 correspondes to the similarity of the aligned neighbors
	if (network1.deg[node1] <= network2.deg[node2])
	{
		al = new bool[ network2.deg[node2] ];
		sim = new float[ network1.deg[node1] ];
		for(int i=0; i<network2.deg[node2]; i++)
		{
			al[i] = false;
		}
		for(int i=0; i<network1.deg[node1]; i++)
		{
			sim[i] = 0;
		}
		for(int i=0; i<network1.deg[node1]; i++)
		{
			for(int j=0; j<network2.deg[node2]; j++)
			{
				if( !al[j] && sim[i] < similarity[ network1.neighbor[node1][i] ][ network2.neighbor[node2][j] ] )
				{
					sim[i] = similarity[ network1.neighbor[node1][i] ][ network2.neighbor[node2][j] ];
					last = j;
				}
			}
			al[last] = true;
			tempS += sim[i];
		}
	}
	else
	{
		al = new bool[network1.deg[node1]];
		sim = new float[ network2.deg[node2] ];
		for(int i=0; i<network1.deg[node1]; i++)
		{
			al[i] = false;
		}
		for(int i=0; i<network2.deg[node2]; i++)
		{
			sim[i] = 0;
		}
		for(int i=0; i<network2.deg[node2]; i++)
		{
			for(int j=0; j<network1.deg[node1]; j++)
			{
				if( !al[j] && sim[i] < similarity[ network1.neighbor[node1][j] ][ network2.neighbor[node2][i] ])
				{
					sim[i] = similarity[ network1.neighbor[node1][j] ][ network2.neighbor[node2][i] ];
					last = j;
				}
			}
			al[last] = true;
			tempS += sim[i];
		}
	}

		if( deg2 >= deg1 && deg2 > 0 )
			tempS /= deg2;
		else if ( deg1 > deg2 && deg1 > 0)
			tempS /= deg1;
		else
			tempS = 1.0;


	delete [] al;
	delete [] sim;
	return tempS;
}

//function part
void  Alignment::readAndMakeData()
{
	     A.Read(network1.name, 1);
		 B.Read(network2.name, 1);

		 nodesA = A.get_cnodes();
		 nodesB = B.get_cnodes();
		 sizeA = A.get_num_nodes();
		 sizeB = B.get_num_nodes();
		// cout<<network1.name<<"=  nodes: "<<sizeA<<"- Edges: "<< A.get_num_edges()<<endl;
		 //cout<<network2.name<<"=  nodes: "<<sizeB<<"- EDges: "<< B.get_num_edges()<<endl;


		 long templ;

		   for(long i =0; i!= sizeA; ++i) {  templ = allnodes.Add(nodesA->GetLabel(i)); gg1.push_back(templ);}
		   for(long i =0; i!= sizeB; ++i) {  templ = allnodes.Add(nodesB->GetLabel(i)); gg2.push_back(templ);}

		   AA = Alloc1(sizeA);
		   if (AA ==NULL) cout<<"error"<<endl;
		   BB = Alloc1(sizeB);
		   if (BB ==NULL) cout<<"error"<<endl ;
		   AB = Alloc2(sizeA, sizeB);
		     if (AB ==NULL) cout<<"error"<<endl ;
		    printf("Finish allocating space for  similarity matrix \n");


		char ontology_file[] = "gene_ontology.1_2.obo";
		char gene_association_file[] = "intact.gene_assocs.txt";
	    Ont.read_go_ids(ontology_file);
	    Ont.read_relations(ontology_file);
	   // printf("Finish reading ontology\n");
	    Ont.add_protein_associations(gene_association_file, allnodes.get_trie());
	    FILE *fi = fopen("GO-ce-sc", "r");
	    allnodes.add_gene_associations_isoform(fi, &Ont);
	    fclose(fi);
	    //printf("Finish adding protein associations\n");
	    cout<<"Finish reading ontology GO-ce-sc and adding protein associations"<<endl;
}
void  Alignment::readBlast()
{
	cout << "Initializing the similarity values from a file" << endl;
	float *sim1= new float[network1.size];
	float *sim2= new float[network2.size];

	for(int i=0; i<network1.size; i++)
	{
		sim1[i]=0;

	}

	for(int i=0; i<network2.size; i++)
		{
			sim2[i]=0;

		}


		 ifstream inputFile;
		 string token1,token2,line, blastFile;
		 float token3;
		 int id1, id2;
	     string f1,f2,f3;

    //read blast data from network1
/*	f1 = network1.name;
    f1.append("-");
	f1.append(network1.name);
	f1.append(".val");
	//cout<<f1<<endl;
	ifstream file1(f1.c_str());
	while (getline(file1, line))
	{
    //cout<<line<<endl;
	istringstream tokenizer(line);
	getline(tokenizer, token1, '\t');
	//cout<<token1<<endl;
	id1= network1.getID(token1);

	getline(tokenizer, token2, '\t');

	id2= network1.getID(token2);

	if ( id1 == id2 )
	{
		getline(tokenizer, token3, '\t');

		sim1[ id1 ] = (float)atof(token3.c_str());
	}
   //  ofstream simila1("sim1.txt");
	//for(int i=0; i<network1.size; i++)
		//{
			//cout<<i<<":  "<<network1.getName(i)<<"    "<<sim1[i]<<endl;
			//simila1<<i<<":  "<<network1.getName(i)<<"    "<<sim1[i]<<endl;
		//}
	}

	f2 = network2.name;
	f2.append("-");
	f2.append(network2.name);
	f2.append(".val");
	//cout<<f2<<endl;
	ifstream file2(f2.c_str());
	while (getline(file2, line))
	{
		istringstream tokenizer(line);
		//cout<<line<<endl;
		getline(tokenizer, token1, '\t');
		//cout<<token1<<endl;
		id1 = network2.getID( token1 );

		getline(tokenizer, token2, '\t');
		//cout<<token1<<"   "<<token2<<endl;
		id2 =  network2.getID( token2 );
		if ( id1 == id2 )
		{
			//tokenizer>>token3;
			//sim2[ id1 ] = token3;
			getline(tokenizer, token3, '\t');
			//cout<<token1<<"   "<<token2<<"  "<<token3<<endl;
			sim2[ id1 ] = (float)atof(token3.c_str());

		}

	//	ofstream simila2("sim2.txt");
			//for(int i=0; i<network2.size; i++)
				//{
					//cout<<i<<":  "<<network2.getName(i)<<"    "<<sim2[i]<<endl;
					//simila2<<i<<":  "<<network2.getName(i)<<"    "<<sim2[i]<<endl;
				//}

	}*/






	blast = new float*[network1.size];
	bioI = new float*[network1.size];
	    for (int c=0; c<network1.size; c++)
	    {
	        blast[c]=new float[network2.size];
	        bioI[c]= new float[network2.size];

	    }
	    for (int c1=0; c1<network1.size; c1++)
	    {
	        for (int c2=0; c2<network2.size; c2++)
	        {
	            blast[c1][c2]=0;
	            bioI[c1][c2]=0;

	        }
	    }



	     tempBio = new float*[network1.size];
	    for (int c=0; c<network1.size; c++) {
	        tempBio[c]=new float[network2.size];
	    }
	    for (int c1=0; c1<network1.size; c1++) {
	        for (int c2=0; c2<network2.size; c2++) {
	            tempBio[c1][c2]=0;
	        }
	    }

	blastFile = network1.name;
	 blastFile.append("-");
	 blastFile.append(network2.name);
	 blastFile.append(".sim");
	 cout<<blastFile<<endl;
	 inputFile.open(blastFile.c_str());
	 while (getline(inputFile, line))
	 {
	         istringstream tokenizer(line);
	        // cout<<line<<endl;
	         getline(tokenizer, token1, '\t');
	         id1= network1.mapName[token1];
	         getline(tokenizer, token2, '\t');
	         id2= network2.mapName[token2];
	         tokenizer >> token3;
	         //cout<<token3<<endl;
	         if(maxScore<token3) maxScore = token3;
	       // cout<<"max:"<<maxScore<<endl;
	         tempBio[id1][id2]=token3;
	        //cout<<id1<<"     "<<id2<<"      "<<tempBio[network1.mapName[token1]][network2.mapName[token2]]<<endl;

	 }


	 //normalize between zero and 1
	     for (int c1=0; c1<network1.size; c1++)
	         for (int c2=0; c2<network2.size; c2++)
	             blast[c1][c2] = tempBio[c1][c2];

	     ofstream hubTemp("hubAlitemp.txt");
	    	 for (int c1=0; c1<network1.size; c1++) {
	    	 	        for (int c2=0; c2<network2.size; c2++) {
	    	 	        	hubTemp<<network1.getName(c1)<<"  "<<network2.getName(c2)<<"  "<<blast[c1][c2]<<endl;;
	    	 	        }
	    	 	    }
	    	 for (int c1=0; c1<network1.size; c1++)
	    	 	    {
	    	 	        for (int c2=0; c2<network2.size; c2++)
	    	 	        {

	    	 	            bioI[c1][c2]= blast[c1][c2]/maxScore;

	    	 	        }
	    	 	    }


}






float Alignment::compNeiBioloSimilarity(int node1, int node2)
{
	bool *alN;
	float *simN;
	int lastN;

	float tempN = 0;

	int degN1 = network1.deg[node1];
	int degN2 = network2.deg[node2];

    // We find a good alignment of neighbors of node1 and node2 heuristicly and then the similarity of node1 and node2 correspondes to the similarity of the aligned neighbors
	if (network1.deg[node1] <= network2.deg[node2])
	{
		//alN = new bool[ network2.deg[node2] ];
		simN = new float[ network1.deg[node1] ];
	/*	for(int i=0; i<network2.deg[node2]; i++)
		{
			alN[i] = false;
		}*/
		for(int i=0; i<network1.deg[node1]; i++)
		{
			simN[i] = 0;
		}
		for(int i=0; i<network1.deg[node1]; i++)
		{
			for(int j=0; j<network2.deg[node2]; j++)
			{


					simN[i] += blast[ network1.neighbor[node1][i] ][ network2.neighbor[node2][j] ];


			}
			//alN[lastN] = true;
			tempN += simN[i];
		}
	}
	else
	{
		//alN = new bool[network1.deg[node1]];
		simN = new float[ network2.deg[node2] ];
		/*for(int i=0; i<network1.deg[node1]; i++)
		{
			alN[i] = false;
		}*/
		for(int i=0; i<network2.deg[node2]; i++)
		{
			simN[i] = 0;
		}
		for(int i=0; i<network2.deg[node2]; i++)
		{
			for(int j=0; j<network1.deg[node1]; j++)
			{


					simN[i] += blast[ network1.neighbor[node1][j] ][ network2.neighbor[node2][i] ];


			}
			//alN[lastN] = true;
			tempN += simN[i];
		}
	}

		if( degN2 >= degN1 && degN2 > 0 )
			tempN /= degN2;
		else if ( degN1 > degN2 && degN1 > 0)
			tempN /= degN1;
		else
			tempN = 0.0;


	//delete [] alN;
	delete [] simN;
	return tempN;

}
float Alignment::computeBioloSimilarity(int node1, int node2, double bb )
{

      float  B= ((1-bb)*compNeiBioloSimilarity(node1, node2)+bb*(bioI[node1][node2]));
      return B;
}

float Alignment::compNeiFuncSimilarity(int node1, int node2)
{

	float *simFNS;
	VLong gon1, gon2, gon1i, gon2i;

	float tempFNS = 0;

	int degFNS1 = network1.deg[node1];
	int degFNS2 = network2.deg[node2];
	 gon1i = allnodes.get_goids_from_node(gg1[node1]);
	 gon2i = allnodes.get_goids_from_node(gg2[node1]);
	if (Ont.function_similarity(gon1i, gon2i, SCHLICKER)>0.5){
					filesemanticfile <<network1.getName(node1)<<" "<<network2.getName(node2)<<" "<<Ont.function_similarity(gon1i, gon2i, SCHLICKER)<< endl;
					}
    // We find a good alignment of neighbors of node1 and node2 heuristicly and then the similarity of node1 and node2 correspondes to the similarity of the aligned neighbors
	if (network1.deg[node1] <= network2.deg[node2])
	{
		//alN = new bool[ network2.deg[node2] ];
		simFNS = new float[ network1.deg[node1] ];
	/*	for(int i=0; i<network2.deg[node2]; i++)
		{
			alN[i] = false;
		}*/
		for(int i=0; i<network1.deg[node1]; i++)
		{
			simFNS[i] = 0;
		}

		for(int i=0; i<network1.deg[node1]; i++)
		{
			for(int j=0; j<network2.deg[node2]; j++)
			{

				  	  gon1 = allnodes.get_goids_from_node(gg1[network1.neighbor[node1][i] ]);
				  	  gon2 = allnodes.get_goids_from_node(gg2[network2.neighbor[node2][j]]);
				  	   string n1=network1.getName(network1.neighbor[node1][i]);
				  			string n2=network2.getName(network2.neighbor[node2][j]);
				  	if (Ont.function_similarity(gon1, gon2, SCHLICKER)>0.5){
				  					filesemanticfile <<n1<<"|"<<n2<<"|"<<Ont.function_similarity(gon1, gon2, SCHLICKER)<< endl;
				  					}
				simFNS[i] += Ont.function_similarity(gon1, gon2, SCHLICKER);


			}
			//alN[lastN] = true;
			tempFNS += simFNS[i];
		}
	}
	else
	{
		//alN = new bool[network1.deg[node1]];
		simFNS = new float[ network2.deg[node2] ];
		/*for(int i=0; i<network1.deg[node1]; i++)
		{
			alN[i] = false;
		}*/
		for(int i=0; i<network2.deg[node2]; i++)
		{
			simFNS[i] = 0;
		}
		for(int i=0; i<network2.deg[node2]; i++)
		{
			for(int j=0; j<network1.deg[node1]; j++)
			{
			  	  gon1 = allnodes.get_goids_from_node(gg1[network1.neighbor[node1][j] ]);
			  	  gon2 = allnodes.get_goids_from_node(gg2[network2.neighbor[node2][i] ]);
			  	string n1=network1.getName(network1.neighbor[node1][i]);
			  			string n2=network2.getName(network2.neighbor[node2][j]);

				  simFNS[i] += Ont.function_similarity(gon1, gon2, SCHLICKER);
					if (Ont.function_similarity(gon1, gon2, SCHLICKER)>0.5){
						filesemanticfile <<n1<<"|"<<n2<<"|"<<Ont.function_similarity(gon1, gon2, SCHLICKER)<< endl;
								  					}


			}
			//alN[lastN] = true;
			tempFNS += simFNS[i];
		}
	}

		if( degFNS2 >= degFNS1 && degFNS2 > 0 )
			tempFNS /= degFNS2;
		else if ( degFNS1 > degFNS2 && degFNS1 > 0)
			tempFNS /= degFNS1;
		else
			tempFNS = 0.0;


	//delete [] alN;
	delete [] simFNS;
	return tempFNS;

}


double Alignment::computeFunctSimilarityI(int node1, int node2)
{
    VLong gos1, gos2;
  	  gos1 = allnodes.get_goids_from_node(gg1[node1]);
  	  gos2 = allnodes.get_goids_from_node(gg2[node2]);
  	  double x = Ont.function_similarity(gos1, gos2, SCHLICKER);

return x;

}


double Alignment::computeFunctSimilarity(int node1, int node2, double bb)
{
	double z = compNeiFuncSimilarity( node1,node2);
			return z;
}












// This function calculates the similarity values of nodes by an iterative approach on it iterations using b and c as weighting parameters. Please see the paper.
void Alignment::setSimilarities(int iteration, double bb, double cc, int op)
{
	float ** tempSim;

	tempSim = new float*[network1.size];

	for(int i=0; i<network1.size; i++)
	{
		tempSim[i] = new float[network2.size];
	}

	for(int i=0; i<network1.size; i++)
		for(int j=0; j<network2.size; j++)
		{
			similarity[i][j] = 1.0;
		}
/*
    // If we want to initiate the similarities by biological similarity values such as blast
	if( bb > 0 )
	{
        
        cout << "Initializing the similarity values from a file" << endl;
        
		float *sim1 = new float[network1.size];
		float *sim2 = new float[network2.size];

		for(int i=0; i<network1.size; i++)
			sim1[ i ] = 0;
		for(int i=0; i<network2.size; i++)
			sim2[ i ] = 0;



		string line;
		string token;
		int id1, id2;



		string f1,f2,f3;

		f1 = network1.name;
		f1.append("-");
		f1.append(network1.name);
		f1.append(".val");
		ifstream file1(f1.c_str());

		while (getline(file1, line))
		{

			istringstream tokenizer(line);
			string token;

			getline(tokenizer, token, '\t');

			id1 = network1.getID( token );

			getline(tokenizer, token, '\t');

			if(token.at(token.length()-1)=='\n')
				token = token.substr(0,token.length()-1);

			id2 =  network1.getID( token );

			if ( id1 == id2 )
			{
				getline(tokenizer, token, '\t');

				if(token.at(token.length()-1)=='\n')
					token = token.substr(0,token.length()-1);

				sim1[ id1 ] = (float)atof(token.c_str());
			}

		}




		f2 = network2.name;
		f2.append("-");
		f2.append(network2.name);
		f2.append(".val");

		ifstream file2(f2.c_str());

		while (getline(file2, line))
		{

			istringstream tokenizer(line);
			string token;

			getline(tokenizer, token, '\t');

			id1 = network1.getID( token );

			getline(tokenizer, token, '\t');

			if(token.at(token.length()-1)=='\n')
				token = token.substr(0,token.length()-1);

			id2 =  network1.getID( token );

			if ( id1 == id2 )
			{
				getline(tokenizer, token, '\t');

				if(token.at(token.length()-1)=='\n')
					token = token.substr(0,token.length()-1);

				sim2[ id1 ] = (float)atof(token.c_str());
			}

		}

		if( reverse )
		{
			f3 = network2.name;
			f3.append("-");
			f3.append(network1.name);
			f3.append(".val");
		}
		else
		{
			f3 = network1.name;
			f3.append("-");
			f3.append(network2.name);
			f3.append(".val");
		}

		ifstream file3(f3.c_str());

		while (getline(file3, line))
		{

			istringstream tokenizer(line);
			string token;

			getline(tokenizer, token, '\t');

			id1 = network1.getID( token );

			getline(tokenizer, token, '\t');

			if(token.at(token.length()-1)=='\n')
				token = token.substr(0,token.length()-1);

			id2 =  network1.getID( token );

			getline(tokenizer, token, '\t');

			if(token.at(token.length()-1)=='\n')
				token = token.substr(0,token.length()-1);

			similarity[ id1 ][ id2 ] = (float)( ( 1 - bb )* 1.0 + bb * 2 * atof(token.c_str()) / ( sim1[ id1 ] + sim2[ id2 ] ) );
		}
	}*/

	int maxSim1;
	int maxSim2;
	int minSim1;
	int minSim2;
	double sumSim;

	ofstream simFile( "simLog.txt");
	//ofstream compfuncSimtempSim("functTempsim.txt");
	ofstream compfunctopoSim3("functopoSim3.txt");

    // The iterative process. At each iteration the similarity will be calculated for all nodes and then we update the similarity values at the end of the iteration.
	for(int it=0; it<iteration; it++)
	{
        cout << "Iteration: " << (it+1) <<"/"<<iteration << endl;
		maxSim1 = 0;
		maxSim2 = 0;
		minSim1 = 0;
		minSim2 = 0;
		sumSim = 0;
     //computing the  topological and fonctional  similarity
      if(op==1)
      {
    	  cout<<"computing the  topo similarity"<<endl;
		for(int i=0; i<network1.size; i++)
		{
			for(int j=0; j<network2.size; j++)
			{
				tempSim[i][j] = (float)(computeSimilarity(i,j));
				//compfuncSimtempSim<<i<<"-"<<j<<"=>"<<tempSim[i][j]<<endl;
				compfunctopoSim3<<i<<"-"<<j<<"=>"<<tempSim[i][j]<<endl;
			}
		}
      }
      //computiong topological and biological similarity
      else if(op==2)
      {
    	 cout<<" computing the func similarity"<<endl;
    	  for(int i=0; i<network1.size; i++)
    	  	{
    	  	 for(int j=0; j<network2.size; j++)
    	  		{
    	  		tempSim[i][j] = (float)(computeFunctSimilarity(i, j, bb));
    	  		//compfuncSimtempSim<<i<<"-"<<j<<"=>"<<tempSim[i][j]<<endl;
    	  		compfunctopoSim3<<i<<" deg: "<<network1.deg[i]<<"- "<<j<<" deg: "<<network2.deg[j]<<" => "<<tempSim[i][j]<<endl;
    	  			}
    	  		}

      }
      //computing the biological and functional similarity
      else if(op==3)
      {
    	  cout<<"computing the  biological and fonctional similarity"<<endl;
    	  for(int i=0; i<network1.size; i++)
    	  	{
    	  		for(int j=0; j<network2.size; j++)
    	  		 {
    	  			tempSim[i][j] = (float)(cc*computeBioloSimilarity(i,j, bb)+(1-cc)*computeFunctSimilarity(i, j, bb));
    	  			//compfuncSimtempSim<<i<<"-"<<j<<"=>"<<tempSim[i][j]<<endl;
    	  			compfunctopoSim3<<i<<"-"<<j<<"=>"<<tempSim[i][j]<<endl;
    	  		}
    	  	}

      }
		for(int i=0; i<network1.size; i++)
		{
			for(int j=0; j<network2.size; j++)
			{
				similarity[i][j] = tempSim[i][j];
				sumSim += similarity[i][j] / network2.size;
				if( similarity[i][j] > similarity[ maxSim1 ][ maxSim2 ] )
				{
					maxSim1 = i;
					maxSim2 = j;
				}
				else if( similarity[i][j] < similarity[ minSim1 ][ minSim2 ] )
				{
					minSim1 = i;
					minSim2 = j;
				}
			}
		}
		sumSim /= network1.size;

		simFile << it << " --------------------------------------" << endl;
		simFile << "Average : " << ( sumSim / network1.size ) << endl;
		simFile << "Maximum : " << " deg[" << maxSim1 << "]=" << network1.deg[maxSim1] << ", deg[" << maxSim2 << "]=" << network2.deg[maxSim2] << ", similarity[" << maxSim1 << "][" << maxSim2 << "]=" << similarity[maxSim1][maxSim2] << endl;
		simFile << "Minimum : " << " deg[" << minSim1 << "]=" << network1.deg[minSim1] << ", deg[" << minSim2 << "]=" << network2.deg[minSim2] << ", similarity[" << minSim1 << "][" << minSim2 << "]=" << similarity[minSim1][minSim2] << endl;

	}
    
    for(int j=0; j<network1.size; j++)
    {
        delete [] tempSim[j];
    }
    delete [] tempSim;

}




//produce a mapping between nodes of two network with respect to input parameter a.
//Input parameter a acontrols the factor edgeWeight in assigning the scores to the nodes. a should be between 0 and 1.
void Alignment::align(double aa)
{



	score = new float*[network1.size];

	for(int i=0; i<network1.size; i++)
	{
		score[i]= new float[network2.size];
	}
	float ss;
	float epsil = 0;

	for(int i=0; i<network1.size; i++)
		for(int j=0; j<network2.size; j++)
		{
			score[i][j]= 0;
		}
	float *tempScore1;
	float *tempScore2;

    // Assigning initial scores corresponding to degrees
	tempScore1 = new float[network1.size];
	for(int i=0; i<network1.size; i++)
	{
		tempScore1[i] = 0;
		for(int j=0; j<network1.deg[i]; j++)
			tempScore1[i] += (float)( 1.0 / network1.deg[network1.neighbor[i][j]] );
	}
	tempScore2 = new float[network2.size];
	for(int i=0; i<network2.size; i++)
	{
		tempScore2[i] = 0;
		for(int j=0; j<network2.deg[i]; j++)
			tempScore2[i] += (float)( 1.0 / network2.deg[network2.neighbor[i][j]] );
	}
	ofstream detailFile( "alignmentDetails.txt");


    // Assigning similarity between nodes of two netwroks just based on their degrees
	for(int i=0; i<network1.size; i++)
		for(int j=0; j<network2.size; j++)
		{
            score[i][j] = (tempScore1[i]<tempScore2[j])?tempScore1[i]/maxDeg:tempScore2[j]/maxDeg;
            //cout<<i<<" "<<j<<" "<<score[i][j]<<endl;
            ss = score[i][j];
            score[i][j] = (float)( (1 - aa) * ss +  aa * similarity[i][j] );
            if( score[i][j] < 0 )
                detailFile << "--------------------------  " << i << " : " << network1.deg[i] << " ----> " << j << " : " << network2.deg[j] << "    Score : " << score[i][j] << endl;

		}


	int nodeSize = network1.size;
	alignment = new int[nodeSize];
	int *nodeScore = new int[nodeSize];
	bool *aligned1 = new bool[nodeSize];
	float *minus = new float[nodeSize];
	bool *aligned2 = new bool[network2.size];
	float *negScore1 = new float[nodeSize];
	float *negScore2 = new float[network2.size];
	int **posScore;

	posScore = new int*[network1.size];

	for(int i=0; i<network1.size; i++)
	{
		posScore[i]= new int[network2.size];
	}



	for(int i=0; i<nodeSize; i++)
	{
		nodeScore[i] = 0;
		aligned1[i] = false;
		negScore1[i] = 0;
	}

	for(int i=0; i<network2.size; i++)
	{
		aligned2[i] = false;
		negScore2[i] = 0;
	}

	for(int i=0; i<nodeSize; i++)
		for(int j=0;j<network2.size; j++)
		{
			posScore[i][j]=0;
			if(score[i][j]>score[i][nodeScore[i]])
				nodeScore[i] = j;
		}
	int maxScore;

	bool ast = true;

    int progress=0;
    // main alignment procedure. At each iteraiton, we find the best alignment and then update the score accordingly
	for(int i=0; i<nodeSize; i++)
	{
        if ( (progress+1) <= (10*(i+1)/nodeSize) + 0.0000001)
        {
            progress++;
            cout << 10*progress << "%"<< endl;
        }
        
		maxScore = -1;
		int cnt = 0;
        
        // finding the best alignment
		for(int j=0; j<nodeSize; j++)
		{
			if(!aligned1[j])
			{
				if(maxScore < 0 )
					maxScore = j;
				else if(score[j][nodeScore[j]] > score[maxScore][nodeScore[maxScore]])
				{
					maxScore = j;
				}
				cnt++;
			}
		}
		if( i+ cnt != 5626 && ast )
		{

				ast = false;
		}

        // updating the alignment vector
		alignment[maxScore] = nodeScore[maxScore];
		aligned1[maxScore] = true;
		aligned2[nodeScore[maxScore]] = true;
		aa -= epsil;

		detailFile << maxScore << " : " << network1.deg[maxScore] << " ----> " << nodeScore[maxScore] << " : " << network2.deg[nodeScore[maxScore]] << "    Score : " << score[maxScore][nodeScore[maxScore]] << "     Similarity" << aa * similarity[maxScore][nodeScore[maxScore]] << endl;

        // decreesing the score of neighbors because of dependency
		for(int j=0; j<network1.deg[maxScore]; j++)
			negScore1[network1.neighbor[maxScore][j]] += (float)( 1.0 / network1.deg[maxScore] );

		for(int k=0; k<network2.deg[nodeScore[maxScore]]; k++)
			negScore2[network2.neighbor[nodeScore[maxScore]][k]] += (float)( 1.0 / network2.deg[ nodeScore[maxScore] ] );

        // aligning the neighbors with degree one
		for(int j=0; j<network1.deg[maxScore]; j++)
			for(int k=0; k<network2.deg[nodeScore[maxScore]]; k++)
				if( !aligned1[network1.neighbor[maxScore][j]] && !aligned2[network2.neighbor[nodeScore[maxScore]][k]])
				{
					if(network1.deg[network1.neighbor[maxScore][j]]==1 && network2.deg[network2.neighbor[nodeScore[maxScore]][k]]==1)
					{
						alignment[network1.neighbor[maxScore][j]] = network2.neighbor[nodeScore[maxScore]][k];

						aligned1[network1.neighbor[maxScore][j]] = true;
						aligned2[network2.neighbor[nodeScore[maxScore]][k]] = true;

						detailFile << "$ " << network1.neighbor[maxScore][j] << " : " << network1.deg[network1.neighbor[maxScore][j]] << " ----> " << network2.neighbor[nodeScore[maxScore]][k] << " : " << network2.deg[network2.neighbor[nodeScore[maxScore]][k]] << "    Score : " << score[network1.neighbor[maxScore][j]][network2.neighbor[nodeScore[maxScore]][k]] << endl;

						aa -= epsil;
						i++;
					}
				}

        // encouraging the neighbors of aligned nodes to align together by increasing the alignment score among them
		for(int j=0; j<network1.deg[maxScore]; j++)
			for(int k=0; k<network2.deg[nodeScore[maxScore]]; k++)
					posScore[network1.neighbor[maxScore][j]][network2.neighbor[nodeScore[maxScore]][k]]++;


        // updating scores
		for(int j=0; j<network1.deg[maxScore]; j++)
			if( !aligned1[network1.neighbor[maxScore][j]] )
				for( int k=0; k<network2.size; k++ )
				{                                                                                                  //C1
                    score[ network1.neighbor[maxScore][j] ][k] = ( ( tempScore1[ network1.neighbor[maxScore][j] ] - negScore1[ network1.neighbor[maxScore][j] ] ) < ( tempScore2[k] - negScore2[k] ) )?( tempScore1[ network1.neighbor[maxScore][j] ] - negScore1[ network1.neighbor[maxScore][j] ] )/maxDeg : ( tempScore2[k] - negScore2[k] )/maxDeg;
					ss =  ((float)posScore[ network1.neighbor[maxScore][j] ][k])/maxDeg + score[ network1.neighbor[maxScore][j] ][k];
					score[ network1.neighbor[maxScore][j] ][k] =  (float)( (1 - aa) * ss + aa * similarity[ network1.neighbor[maxScore][j] ][k] );

				}
        // updating scores
		for(int k=0; k<network2.deg[nodeScore[maxScore]]; k++)
			if( !aligned2[network2.neighbor[nodeScore[maxScore]][k]] )
				for( int j=0; j<network1.size; j++ )
				{
                    score[j][ network2.neighbor[nodeScore[maxScore]][k] ] = ( ( tempScore1[j] - negScore1[j] ) < ( tempScore2[ network2.neighbor[nodeScore[maxScore]][k] ] - negScore2[ network2.neighbor[nodeScore[maxScore]][k] ] ) )?( tempScore1[j] - negScore1[j] )/maxDeg : ( tempScore2[ network2.neighbor[nodeScore[maxScore]][k] ] - negScore2[ network2.neighbor[nodeScore[maxScore]][k] ])/maxDeg;
					ss = ((float)posScore[j][ network2.neighbor[nodeScore[maxScore]][k] ])/maxDeg + score[j][ network2.neighbor[nodeScore[maxScore]][k] ];
					score[j][ network2.neighbor[nodeScore[maxScore]][k] ] = (float)( (1 - aa) * ss + aa * similarity[j][ network2.neighbor[nodeScore[maxScore]][k] ] );
				}

        // updating scores
		for(int k=0; k<network2.deg[nodeScore[maxScore]]; k++)
			if( !aligned2[network2.neighbor[nodeScore[maxScore]][k]] )
				for( int j=0; j<network1.size; j++ )
				{
					if( nodeScore[ j ] == network2.neighbor[nodeScore[maxScore]][k] )
					{
							for(int l=0;l<network2.size; l++)
								if(score[ j ][l]>score[j][nodeScore[j]])
									nodeScore[j] = l;
					}
				}
        
        // updating scores
		for(int j=0; j<network1.deg[maxScore]; j++)
			if( !aligned1[network1.neighbor[maxScore][j]] )
				for( int k=0; k<network2.size; k++ )
				{
					if(score[ network1.neighbor[maxScore][j] ][k]>score[ network1.neighbor[maxScore][j] ][nodeScore[ network1.neighbor[maxScore][j] ]])
									nodeScore[ network1.neighbor[maxScore][j] ] = k;
				}

        // We don't want to align a node that is already aligned again
		for(int j=0; j<nodeSize; j++)
		{
			if(aligned2[nodeScore[j]])
			{
				score[j][nodeScore[j]] = -1;
			}
		}
        
        // finding the best candidate alignments for each node again
		for(int j=0; j<nodeSize; j++)
		{
			if(aligned2[nodeScore[j]])
			{
				for(int k=0;k<network2.size; k++)
					if(score[j][k]>score[j][nodeScore[j]] && !aligned2[k])
						nodeScore[j] = k;
			}
		}

	}
    cout << endl;

    for(int j=0; j<network1.size; j++)
    {
        delete [] score[j];
        delete [] posScore[j];
    }
    delete [] score;
    delete [] posScore;
    
    delete [] tempScore1;
	delete [] tempScore2;
	delete [] aligned1;
	delete [] aligned2;
	delete [] negScore1;
	delete [] negScore2;
    delete [] minus;
    delete [] nodeScore;
    
    // evaluate the alignment
	evaluate();

}


//calculate the evaluation measurments EC (Edge Correctness), IC (Interaction Correctness), NC (Node Correctness), CCCV and CCCE (largest Common Connected subraph with recpect to Vertices and Edges)
void Alignment::evaluate(void)
{
	CCCV = getCCCV(); //calculate CCCV
	CCCE = getCCCE(); //calculate CCCE
	EC = getEC();     //calculate Edge Correctness
	NC = getNC();     //calculate Node Correctness
	IC = getIC();     //calculate Interaction Correctness
	S3 = getS3();     //calculate Symmetric substructure score
}

//calculate CCCV
//return the number of vertices of largest common connected subgraph of the alignment
int Alignment::getCCCV(void)
{
    int *subGraph;
    int compNum = 1; //number of connected components
	int *q = new int[network1.size]; //nodes that are already processed
	comp = new int[network1.size]; //dtermines the connected component each node belongs to.
	for(int i=0; i<network1.size; i++)
	{
		comp[i] = network1.size;
		q[i] = i;
	}
    
	int last = 0;
    
	//for each node of the network
    for(int i=0; i<network1.size; i++)
	{
		if(comp[i]==network1.size)
		{
			q[0] = i;
			comp[i] = compNum;
			compNum++;
			last = 1;
            //finds all connected nodes tho the node i that is not alredy in a connected component
			for(int k=0; k<last; k++)
				for(int j=0; j<network1.deg[q[k]]; j++)
                    //the node is not already processed
					if( comp[q[k]] < comp[network1.neighbor[q[k]][j]])
					{
						for( int l=0; l < network2.deg[alignment[q[k]]]; l++ )
							if(network2.neighbor[alignment[q[k]]][l] == alignment[network1.neighbor[q[k]][j]])
							{
								comp[network1.neighbor[q[k]][j]] = comp[q[k]];
								q[last] = network1.neighbor[q[k]][j];
								last++;
							}
					}
		}
	}
    
	subGraph = new int[compNum-1]; //array of connected components
	for(int i=0; i<compNum-1; i++)
		subGraph[i] = 0;
	for(int i=0; i<network1.size; i++)
		subGraph[comp[i]-1]++; //number of nodes in a definit connected component
    
	//find the component with maximum nodes
    maxComp = 0;
	for(int i=0; i<compNum-1; i++)
	{
		if(subGraph[maxComp] < subGraph[i])
			maxComp = i;
	}
    
    int temp = subGraph[maxComp];
    
    //memory leak
    delete [] subGraph;
    delete [] q;
    
	return temp;
}

//calculate the evaluation measurment CCCE
//return the number of edges of largest common connected subgraph of the alignment
int Alignment::getCCCE(void)
{
	int edgeComp = 0;
    //for each node of first network
	for(int i=0; i<network1.size; i++)
	{
        //for each neighbor of node i
		for(int j=0; j<network1.deg[i]; j++)
            //for each neighbor l of a node in second network that is aligned with node i
			for( int l=0; l < network2.deg[alignment[i]]; l++ )
				if(network2.neighbor[ alignment[i] ][l] == alignment[network1.neighbor[i][j]])
					if( comp[i]-1 == maxComp)
						edgeComp++;
	}
    
	return ( edgeComp / 2 );
}

//calculate the evaluation measurment EC
//returns the percent of edges that are mapped correctly in alignment
float Alignment::getEC(void)
{
	int totalScore=0;
    
	//for each node i in first network
    for(int i=0; i<network1.size; i++)
	{
        //for each neighbor j of node i
		for(int j=0; j<network1.deg[i]; j++)
			//for each neighbor l of a node in second network that is aligned with node i
            for( int l=0; l < network2.deg[alignment[i]]; l++ )
				if(network2.neighbor[ alignment[i] ][l] == alignment[ network1.neighbor[i][j] ])
					totalScore++;
	}
    
	//minimum number of edges of two networks
    int minEdge = ( network1.numOfEdge > network2.numOfEdge)? network2.numOfEdge : network1.numOfEdge;
    //calculate EC(edge correctness)
	return ( (float) totalScore ) / ( 2 * minEdge );
}
float Alignment::getS3(void)
{
	int totalScore=0;
    int* alignnodes = new int[network1.size];
    int num_edge_net2=0;

	//for each node i in first network
    for(int i=0; i<network1.size; i++)
	{
        alignnodes[i]=alignment[i];
        //for each neighbor j of node i
        for(int j=0; j<network1.deg[i]; j++)
			//for each neighbor l of a node in second network that is aligned with node i
            if (alignment[i] != -1)
                for( int l=0; l < network2.deg[alignment[i]]; l++ )
                {
                    if(network2.neighbor[ alignment[i] ][l] == alignment[ network1.neighbor[i][j] ])
                    {
                        totalScore++;
                    }
                }
	}
    totalScore=totalScore/2;

    for(int i=0; i<network1.size; i++)
        if (alignment[i] != -1)
            for(int j=0; j<network2.deg[alignnodes[i]]; j++)
                for(int l=0; l<network1.size; l++)
                    if(network2.neighbor[alignnodes[i]][j]==alignnodes[l])
                        num_edge_net2++;
    num_edge_net2=num_edge_net2/2;
	//minimum number of edges of two networks
    int minEdge = ( network1.numOfEdge > network2.numOfEdge)? network2.numOfEdge : network1.numOfEdge;
    //calculate EC(edge correctness)
	return ( (float) totalScore ) / ( minEdge + float(num_edge_net2) - totalScore );
}

//calculate the evaluation measurment NC
//returns percent of nodes that are mapped correctly in alignment
float Alignment::getNC(void)
{
	int nc = 0;
    //for each node in fist network
	for( int i=0; i<network1.size; i++)
        //check wether or not a node has aligned correctly.
        if( network1.getID( network2.getName ( alignment[i] ) ) == i )
			nc++;
    
	return ( (float)nc / network1.size );
}

//calculate the evaluation measurment IC
//returns percent of interactions that are mapped correctly in alignment
float Alignment::getIC(void)
{
	int ic = 0; //interaction correctness
    //for each node i of first network
	for(int i=0; i<network1.size; i++)
	{
        //for each node j of neighbors of node i
		for(int j=0; j<network1.deg[i]; j++)
            //for each neighbor l of a node in second network that is aligned with node i
			for( int l=0; l < network2.deg[alignment[i]]; l++ )
                //compare the neighbores of two aligned nodes to check wether or not they are aligned.
				if(network2.neighbor[ alignment[i] ][l] == alignment[network1.neighbor[i][j]])
					if( network1.getID( network2.getName ( alignment[i] ) ) == i && network1.getID( network2.getName ( alignment[network1.neighbor[i][j]] ) )== network1.neighbor[i][j] )
						ic++;
	}
    
	int minEdge = ( network1.numOfEdge > network2.numOfEdge)? network2.numOfEdge : network1.numOfEdge;
    
	return ( (float) ic ) / ( 2 * minEdge );
}

//print the evaluation measurments in a file with input parameter name
//Input parameter name determines the file that result are to be written in.
void Alignment::outputEvaluation(string name)
{
    
    // print in consule
	cout << "==============================================================================" << endl;
	cout << "--> Largest Connected Component:   Nodes = " << CCCV <<"   Edges = " << CCCE << endl;
    cout << "--> Edge Correctness           :   " << EC << endl;
    cout << "-->Symmetric substructure score:   " << S3 << endl;
    cout << "==============================================================================" << endl;
    
    
	string outFile = name;
    //add a definit suffix to the file
	outFile.append(".eval");
	ofstream outputFile( outFile.c_str());
    
    //print in file
	outputFile << "==============================================================================" << endl;
	outputFile << "--> Largest Connected Component  :   Nodes= " << CCCV <<"    Edges= " << CCCE << endl;
	outputFile << "--> Edge Correctness             :   " << EC << endl;
    outputFile << "--> Node Correctness             :   " << NC << endl;
    outputFile << "--> Interaction Correctness      :   " << IC << endl;
    outputFile << "--> Symmetric substructure score :   " << S3 << endl;
}

//print the alignment(mapping) in a file with input parameter name
//Input parameter name determines the file that mapping is to be written in.
void Alignment::outputAlignment(string name)

{
    
	string alignFile = name;
    
	//insert a definite suffix for the alignment file
    alignFile.append(".tab");
    
    
	ofstream alignmentFile("ppinac_alignment.txt");
    
	if(reverse) //the second input network is smaller
		for(int i=0; i<network1.size; i++)
			alignmentFile << network1.getName( alignment[ i ] ) << "\t" << network2.getName( i )<< endl;
	else //the first input network is smaller
		for(int i=0; i<network1.size; i++)
			alignmentFile << network1.getName( i ) << "\t" << network2.getName( i ) << endl;
}
//instructor
Alignment::Alignment(void)
{
}
//destructor
Alignment::~Alignment(void)
{
}
