#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>


#ifndef __TrieTree__
#define __TrieTree__


#define SearchError -2
#define SearchNonExist -5

class CTrieNode{//***

  char label; //label of the node
  long  index; //index of the node; -1: no index -> index of the protein in the database
  long  id;    // id of the node in the prefix tree
  long  nc; //number of children
  long  ns; //size of child
  CTrieNode **child;

public:
 // CTrieNode();
  CTrieNode()
  {
    nc = 0;
    label = '.';
    index = -1;
    id = -1;
    ns = 0;
    ExtendSize();
  }
 // ~CTrieNode();
  ~CTrieNode()
  {
    //  printf("Out of TrieNode\n");

    if (child!= NULL)
      {
        for (long i = 0; i != nc; ++i) if (child[i] != NULL) delete child[i];
        free(child);
        child = NULL;
      }
  }
  long Exist(char *s)//***
  {

    if (strlen(s) == 0) return SearchError;
    if (s[0] != label) return SearchNonExist;

    if (strlen(s) == 1)
      return index;

    for (long i = 0; i != nc; ++i)
      {
        long x = child[i]->Exist(&s[1]);
        //cout<<&s[1]<<endl;
        if (x >= 0) return x;
        //cout<<x<<endl;
      }

    return SearchNonExist;
  }
  char Label() { return label;}
  long  ID() {return id;}
  void SetUp(char c) { label = c;}
  void SetUpIndex(long nid) { index = nid;}
  void SetUpID(long xid) {id = xid;}
  void ExtendSize(void)//Extend size of children set by 10 //***
  {
    /*
    child =(CTrieNode**) realloc((CTrieNode**) child, (ns+10) * sizeof(CTrieNode*));
    for (long i = ns; i != ns+10; ++i) child[i] = NULL;
    ns+= 10;
    */
    CTrieNode **p = (CTrieNode**)calloc(ns+10, sizeof(CTrieNode *));
    for (long i = 0; i != ns+10; ++i) p[i] = NULL;

    for (long i = 0; i != nc; ++i)
      p[i] = child[i];

    if (ns >0)
      {
        free(child);
      }
    child = p;
    ns+= 10;

  }
  void Add(char *s, long nid, long *xid)//***+
  {
    if (strlen(s) == 0) {return;}


    if (s[0] != label)
      {
        printf("error: %c %c\n", s[0], label);
        exit(1);
      }


    if (id == -1)
      {
        id = *xid;
        *xid  = (*xid)+1;
      }
    if (strlen(s) == 1)
      {
        if (index != -1) //
  	{
  	  printf("error in searching or something wrong\n");
  	  exit(1);
  	}

        index = nid;
        return;
      }

    for (long i = 0; i != nc; ++i)
      if (child[i]->Label() == s[1])
        {
  	child[i]->Add(&s[1], nid, xid);
  	return;
        }

    if (nc +1 >= ns)  ExtendSize();
    child[nc] = new CTrieNode;

    child[nc]->SetUp(s[1]);

    if (strlen(s) == 1) child[nc]->SetUpIndex(nid);
    else
      {
        child[nc]->Add(&s[1], nid, xid);
      }
    nc++;
  }
  void Add(long nid, char lab, long numchild, long  *children)
  {
    Add(nid, lab, numchild);
    child = (CTrieNode **) calloc(nc, sizeof(CTrieNode *));
    //while(nc >ns+1) ExtendSize();

    for(long i = 0; i!= nc; ++i)
      child[i] = (CTrieNode *) calloc(1, sizeof(CTrieNode));

    for(long i = 0; i!= nc; ++i)
      {
        child[i]->SetUpID(children[i]);
        //      printf("%d\t", child[i]->ID());
      }

    //  printf("\n");
  }
  void Add(long nid, char lab, long numchild) {index = nid; label = lab; nc = numchild; }
  void printNode(FILE *f)
  {
    fprintf(f, "%d\t%d\t%c\t%d\t", id, index, label, nc);
    for(long i = 0; i!= nc; ++i) fprintf(f, "%d\t", child[i]->ID());
    fprintf(f, "\n");
    if (nc ==0) return;
    for(long i = 0; i!= nc; ++i) child[i]->printNode(f);
  }
  CTrieNode *Search(long xid) {
	  if (id == xid)   {return this;}
	  for(long i =0; i!= nc; ++i)
	    {
	      CTrieNode *p = child[i]->Search(xid);
	      if ( p != NULL) return p;
	    }
	  return NULL;
	}









} ;




class CTrieTree//***
{

protected:
  #define MaxLen 128
  char buffer[MaxLen];
  long n; //number of node having index
  long nn; // number of nodes
  CTrieNode *R;

  void adddot(char *s)//***
  {
	  if (s[0] != '.') sprintf(buffer, ".%s", s);
	  else strcpy(buffer, s);
	  //cout<<s<<endl;
}

public:
  CTrieTree()
{
  R = new CTrieNode;
  n = 0;
  nn = 0;
}
  ~CTrieTree()
  {
    //  printf("out of TrieTree\n");
    if (R!= NULL) delete R;
    R = NULL;
  }
  void Read(FILE *f)     //*Read a list of protein name and construct a prefix tree from this
  {
    //input file contain protein names only
    char buffer[MaxLen];
    while (!feof(f))
      {
        fscanf(f, "%s", buffer);
        Add(buffer);
      }
  }
  void LoadTrie(FILE *f) //*Load a TrieTree that has been written down by PrintTrie();
  {
    long start = 0;
    R->SetUpID(0);

    while (!feof(f))
      {
        long xid, nid;
        char lab;
        long nc;
        fscanf(f, "%d %d %c %d", &xid, &nid, &lab, &nc );

         //      printf("solving node %d\n", xid);

        CTrieNode *temp =  R->Search(xid);

        if (nc >0)
  	{
  	  long child[nc];
  	  for(long i = 0; i!= nc; ++i) fscanf(f, "%d", &child[i]);
  	  //add info to available node
  	  temp->Add(nid, lab, nc, child);
  	}
        if (nc == 0)
  	temp->Add(nid, lab, nc); //add info to available node
        start++;
      }
  }
  long Search(char *s)//***
  {
    adddot(s);
    return R->Exist(buffer);
    //cout<<"R: "<<R<<endl;
  }
  long Add(char *s)//***+
  {
    adddot(s);
    long x = Search(s);

    if (x < 0) //not exist
      R->Add(buffer, n++, &nn);
    return n;
  }
  void PrintTrie(FILE *f)
  {
    R->printNode(f);
  }
  long  Size() {return n;} //get number of protein encoded by the tree
};


#endif
