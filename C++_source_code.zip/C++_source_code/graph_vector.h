//s
#ifndef GRAPH_VECTOR_H_
#define GRAPH_VECTOR_H_

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "nodes.h"
#include<algorithm>


#define MaxNumEdge 200000
#define MaxNumNode 50000


class CGraph
{
	 CNodes nodes;
	 void GetProteinName(char *st, char *ptn)
	 {

		  char *p1 = st;
		  char temp1[MaxLen], temp2[MaxLen];
		  sscanf(p1, temp1, '|');        //get the first accession number in the list of them

		  char *p2 = strstr(temp1, ":"); // find the ":" character, if there is, get the accession number after it, else it is the accession number with no database info

		  long length=0;                  //length of protein name

		  if (p2 == NULL) p2 = temp1;
		  else p2++;

		  for(char *p = p2; p!= temp1 + strlen(temp1); ++p) ptn[length++] = p[0];
		  ptn[length] = '\0';
		  if (length > 30 || length == 0)
		    printf("%s length = %d\n", ptn, length);

	 }
	 long num_edges;
	 VDouble node_scores;
	 VVLong adlist;
	 long isIn(long id, VLong x)
	 {
	   if (x.size() ==0) return -1;
	   if (x.size() ==1 && id != x[0]) return -1;
	   if (x.size() ==1 && id == x[0]) return 0;

	   long low = 0;
	   long high = x.size();
	   long mid;
	   while (low < high)
	     {
	       mid = (low + high) / 2;
	       if (x[mid] < id) low = mid + 1;
	       else high = mid;
	     }
	   //  printf("is In\n");
	   if (x[low] == id)
	     return low;
	   else   return -1;
	 }

	 void LineProcess(char *buffer, long option)
	 {

		   char s1[MaxLen], s2[MaxLen], s3[MaxLen], s4[MaxLen], ns1[MaxLen], ns2[MaxLen];


		   if (option ==0)
		     {
		       sscanf(buffer, "%s %s %s %s", s1, s2, s3, s4);//node info is in s3 and s4
		       GetProteinName(s3, ns1);
		       GetProteinName(s4, ns2);
		     }
		   else
		     {
		       sscanf(buffer, "%s %s ", s1, s2);//node info is in s1 and s2
		       //cout<<"s1: "<<s1<<" s2: "<<s2<<endl;
		       strcpy(ns1, s1);
		       //cout<<"ns1: "<<ns1<<endl;
		       strcpy(ns2, s2);
		       //cout<<"ns2: "<<ns2<<endl;
		     }

		   long id1 =  nodes.Add(ns1);
		   //cout<<id1<<endl;
		   long id2 =  nodes.Add(ns2);
		   //cout<<id2<<endl;
		   long size1 = std::max(id1, id2) - adlist.size() +1;
		   //cout<<size1<<endl;
		   if (size1 >0)
		     {
		       VLong tempV;
		       for(long i =0; i!= size1; ++i)	 adlist.push_back(tempV);
		     }

		   if (isIn(id2, adlist[id1]) <0) {adlist[id1].push_back(id2); sort(adlist[id1].begin(), adlist[id1].end());}
		   if (isIn(id1, adlist[id2]) <0) {adlist[id2].push_back(id1); sort(adlist[id2].begin(), adlist[id2].end());}

	 }

public:
  CGraph()
    {
      num_edges=0;
    }
  ~CGraph()
    {
    }
  //Nodes
   long get_num_nodes(){return nodes.GetNumNodes();}
   long get_num_edges()
   {

	   if (num_edges>0) return num_edges;

	   for(long i=0; i!= adlist.size(); ++i)
	     {
	       for(long j=0; j!= adlist[i].size(); ++j)
	 	if (adlist[i][j] >= i) num_edges++;

	     }
	   printf("in here\n");
	   return num_edges;

   }
   char *get_label(long gid) {return nodes.GetLabel(gid);}
   VVLong GetEdges() {return adlist;}

   //Edges and graphs
    //long get_num_edges(){return Edges[0].size();}
    void Read(char *fn, long option)             //option = 0: read from original file (taxid taxid protein1 protein2 - protein names has database name attached)
    	{                                        //option = 1: read from simpler file (protein1 protein2- simply take in protein names and do not care about databases)

    	  FILE * fi = fopen(fn, "r");
    	  Read(fi, option);
    	  fclose(fi);

    	}
    void Read(FILE *f, long option)
    {

    	   long buff_size = 15000;
    	   char buffer[buff_size];

    	   while(!feof(f))
    	     {
    		   //cout<<buffer<<endl;
    	       strcpy(buffer, "");
    	       fgets(buffer, buff_size, f);
    	       //cout<<buffer<<endl;
    	       if (strlen(buffer) <1) break;
    	       LineProcess(buffer, option);
    	     }

    }
    CNodes *get_cnodes(){return &nodes;}//*****
    VLong GetNeigh(long lid) {return adlist[lid];}
    VLong Get2Neigh(long gid);
    long IsNeighbour(long id1, long id2);
    void assign_node_scores(VDouble x) {node_scores = x;}

    void Write2GraphML(char *fn);
    void Write2GraphML(FILE *f);

    void Write2HTML(char *fn);
    void Write2HTML(FILE *f);








};


#endif
