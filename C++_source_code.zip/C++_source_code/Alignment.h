#pragma once

#include "Network.h"
#include <iostream>
#include <cstdlib>
#include "math.h"
#include <time.h>
#include<string.h>
#include <fstream>
//#include"TrieTree.cpp"
#include"TrieTree.h"
#include"nodes.h"
//#include"nodes.cpp"
#include"go_sim.h"
//#include"go_sim.cpp"
#include"graph_vector.h"

using namespace std;



class Alignment
{
	COntology_RW Ont;
	CNodes allnodes, *nodesA, *nodesB;
	VLong   gg1, gg2;
	CGraph A, B;
	long sizeA, sizeB;
	double **AA,**BB, **AB;
public:
	double initial_val =0;
	float **similarity; // The similarity values of nodes
	float **score;
	float **blast;
	float ** tempBio;
	float maxScore = 0 ;
	float **bioI;




	//measures for evaluating the alignment
    float EC, IC, NC,S3;
	int CCCV,CCCE;

	int *alignment; //array of alignment of two networks
	int *comp; //array of connected components in the resulted alignment
	int maxComp; //maximum connected component of the resulted alignment
	int maxDeg; //max degree of two networks
	bool reverse; //determine which networks is bigger
	Network network1;
	Network network2;
    
    //constructor
    //finds the smaller network and the maximum degree of the input networks
    //Inputs are two files of networks net1 and net2
	Alignment( Network net1, Network net2 );
	
    //constructor.does nothing !
    Alignment(void);
    
    //destructor
	~Alignment(void);
    
    //produce a mapping between nodes of two network with respect to input parameter a.
    //Input parameter a acontrols the factor edgeWeight in assigning the scores to the nodes. a should be between 0 and 1.
    void align(double a);
    
    // calculates the similarity values of nodes by an iterative approach on it iterations using b and c as weighting parameters. Please see the paper.
	void setSimilarities(int it, double b, double c, int o);
	//
	float compNeiBioloSimilarity(int node1, int node2);
    //
	float compNeiFuncSimilarity(int node1, int node2);
	//
	float computeBioloSimilarity(int node1, int node2, double b);
	double  computeFunctSimilarityI(int node1, int node2);
	//
	double  computeFunctSimilarity(int node1, int node2, double b);
	void  readAndMakeData();
	void  readBlast();
	//calculate the evaluation measurments EC (Edge Correctness), IC (Interaction Correctness), NC (Node Correctness), CCCV and CCCE (largest Common Connected subraph with recpect to Vertices and Edges)
	void evaluate(void);
    
	//calculate CCCV
    //return the number of vertices of largest common connected subgraph of the alignment
    int getCCCV(void);
    
    //calculate the evaluation measurment CCCE
    //return the number of edges of largest common connected subgraph of the alignment
    int getCCCE(void);
    
    //calculate the evaluation measurment EC
    //returns the percent of edges that are mapped correctly in alignment
	float getEC(void);
	float getS3(void);
    
    //calculate the evaluation measurment NC
    //returns percent of nodes that are mapped correctly in alignment
    float getNC(void);
    
    //calculate the evaluation measurment IC
    //returns percent of interactions that are mapped correctly in alignment
	float getIC(void);
    
    //print the evaluation measurments in a file with input parameter name
	//Input parameter name determines the file that result are to be written in.
    void outputEvaluation(string name);
    
    //print the alignment(mapping) in a file with input parameter name
	//Input parameter name determines the file that mapping is to be written in.
	void outputAlignment(string name);
	void outputAlignment1(string name);
	 VVLong adlist;
	 VLong neigh1, neigh2;
	 VLong GetNeigh(long lid) {return adlist[lid];}
	double **Alloc1(long size)
	{
	  double **out;
	  out = (double**) malloc(size * sizeof(double*));
	  if (out == NULL) return NULL;
	  long i, j;
	  for(i =0; i!= size; ++i)
	    {
	      out[i] = (double *)malloc((i+1) * sizeof(double));
	      for(long j=0; j!= i+1; ++j) out[i][j] = initial_val; //default =0
	      if (out[i] ==NULL) break;
	    }

	  if (i < size)
	    {
	      j = i;
	      for(i =1; i!=j; ++i) free(out[i]);
	      return NULL; //not enough memory
	    }
	  return out;
	}
	double **Alloc2(long size1, long size2)
	{
	  double **out;
	  out = (double**) malloc(size1 * sizeof(double*));
	  if (out == NULL) return NULL;

	  long mem = 0;
	  long i, j;
	  for(i =0; i!= size1; ++i)
	    {
	      out[i] = (double *)malloc(size2 * sizeof(double));
	      for(long j=0; j!= size2; ++j) out[i][j] = initial_val; //default: = 0
	      if (out[i] ==NULL){mem = 1;  break;}
	    }

	  if (mem == 1)
	    {
	      j = i;
	      for(i =0; i!=j; ++i) free(out[i]);
	      printf("not enough memory");
	      return NULL; //not enough memory
	    }
	  return out;
	}
private:
	float computeSimilarity(int node1, int node2);

};
