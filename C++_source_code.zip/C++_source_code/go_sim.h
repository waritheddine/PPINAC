//s
#ifndef GO_SIM_H_
#define GO_SIM_H_

#include<string.h>
#include<vector>
#include <math.h>

#include"TrieTree.h"

enum OntologyType {CC, MF, BP} ; //cellular component, molecular function, biological process
enum RelationType {ISA, PARTOF};
enum SemSimType {RESNIK, LIN, JIANG, RELEVANCE, WANG}; //semantic similarity type
enum FuncSimType {MAX, AVERAGE, SCHLICKER, WANG2}; //functional similarity type
typedef std::vector<long> VLong;
typedef std::vector<double> VDouble;
typedef std::vector<VLong> VVLong;

class CGOTerm
{
protected:
long id,  ontology_type;
char goid[15];
char name[1028]; //description of goterm (to make it easier to understand the term);
VLong parents, ancestors, children, parent_relations, children_relations;
long initx;

public:
CGOTerm()//+
{
}
~CGOTerm()//+
{
  parents.clear();
  parent_relations.clear();
  children.clear();
  children_relations.clear();
  ancestors.clear();
}
void init_goterm(long iid, char* goiid, char *namex, long ont_type)//***+
{
	id = iid;
	strcpy(goid, goiid);
	strcpy(name, namex);
	ontology_type = ont_type;
	add_ancestor(iid);
	initx =1;

}
void add_parent(long iid, long r_type)  //***+
{
	//cout<<"parents.size(): "<<parents.size()<<endl;
  for(long i =0; i!= parents.size(); ++i)
    if (parents[i] == iid) return;
  parents.push_back(iid);
  parent_relations.push_back(r_type);
}
void add_ancestor(long iid)//***+
{
  for(long i = 0; i!= ancestors.size(); ++i)
    if (ancestors[i] == iid) return;
  ancestors.push_back(iid);
}
void add_child(long iid, long r_type)//***+
{
	//cout<<"children.size(): "<<children.size()<<endl;
  for(long i=0; i!= children.size(); ++i)
    if (children[i] == iid) return;
  children.push_back(iid);
  children_relations.push_back(r_type);
}
char *get_goid() {return goid;}//-
long get_id() {return id;}//***+
long get_ont_type(){return ontology_type;}//***
char *get_name(){return name;}//-
VLong get_ancestors(){return ancestors;}//***
long get_ancestor(long i){return ancestors[i];}//***
long get_num_ancestor(){return ancestors.size();}//***
VLong get_parents(){return parents;}//-
long get_parent(long i){return parents[i];}//***
long get_num_parents(){return parents.size();}//***
VLong get_children() {return children;}//-

};


// This class is used to compute the Resnik semantic similarity

class CGOTerm_RW: public CGOTerm//***
{
	long n_prot; // number of protein being annotated to itself both directly and indirectly
	  VLong prots;
	  //for Wang's method
	  VDouble ancestor_scores;
	 double semantic_value;

	 public:
	  CGOTerm_RW():CGOTerm()
	    {
	      n_prot =0;
	     // semantic_value = 0;
	     }

	    ~CGOTerm_RW()
	      {
	      };
	    void add_annotation(long prot_id) //***
	    {

	      for(long i=n_prot-1; i!= -1; --i)
	        if(prots[i] == prot_id)
	    	return;
	      prots.push_back(prot_id);
	      n_prot++;
	    }
	    long get_num_prot(){return n_prot;}//***
	    VLong get_prots(){return prots;}//-
	    void update_protein_count(long count) {n_prot = count;}
	    double get_ancestor_score(long i){return ancestor_scores[i];}//***
	    double get_semantic_value() {return semantic_value;}//***
};


class COntology_RW//***
{
	  CGOTerm_RW **terms;
	  long n_terms, n_type[3], n_protein; //n_protein: number of proteins being assigned, n_type[CC] number of proteins being assigned to CC ontology and so on
	  long roots[3];
	  VLong mark;

	  CTrieTree Trie;  //to store and seach GOID quickly //***

	  VDouble sem_sim; //Semantic similarity array, a n*(n+1)/2 array  with n = n_terms
	  double w1, w2; //for Wang's method, w1 is for is_a relationship contribution, w2 is for part_of relationship contribution

	  double semantic_similarity_resnik(long id1, long id2)//***+
	  {
	    long ot = terms[id1]->get_ont_type();
	    long na1, na2;
	    na1 = terms[id1]->get_num_ancestor();
	    na2 = terms[id2]->get_num_ancestor();

	    long min = 300000;
	    for(long ii=0; ii!= na1; ++ii)
	      for(long jj=0; jj!= na2; ++jj)
	        {
	  	long ac1 = terms[id1]->get_ancestor(ii);
	  	long ac2 = terms[id2]->get_ancestor(jj) ;
	  	if ( ac1 == ac2 )
	  	  {
	  	    long np = terms[ac1]->get_num_prot() ;
	  	    if (np>= 0 && np <min)
	  	      min = np;

	  	  }
	      }
	    if (min ==0) return 0;
	    double minf = (double) min;
	    return  -log(minf/n_type[ot]);
	  }
	  double semantic_similarity_jiang(long id1, long id2)//***+
	  {
	    double ica = semantic_similarity_resnik(id1, id2);
	    long np1 = terms[id1]->get_num_prot();
	    long np2 = terms[id2]->get_num_prot();
	    if (ica ==0 || np1 ==0 ||np2 ==0 ) return 0;
	    return (double) 1/ (- 2*ica  + term_information(id1) + term_information(id2)  +1);
	  }
	  double semantic_similarity_relevance(long id1, long id2)//***+
	  {
	    long ot = terms[id1]->get_ont_type();

	    long na1, na2;
	    na1 = terms[id1]->get_num_ancestor();
	    na2 = terms[id2]->get_num_ancestor();

	    if (id1 == id2)
	      {
	        double np =(double) terms[id1]->get_num_prot();
	        return 1 - np/n_type[ot];
	      }
	    long  ca;
	    long min = 300000;
	    for(long ii=0; ii!= na1; ++ii)
	      for(long jj=0; jj!= na2; ++jj)
	        {
	  	if (terms[id1]->get_ancestor(ii) == terms[id2]->get_ancestor(jj))
	  	  {
	  	    long common_ancestor = terms[id1]->get_ancestor(ii);
	  	    long np = terms[common_ancestor]->get_num_prot();
	  	    if ( np >=0 && np< min)
	  	      {
	  		ca = common_ancestor;
	  		min = np;

	  	    }
	  	  }
	        }
	    long np1 = terms[id1]->get_num_prot();
	    long np2 = terms[id2]->get_num_prot();
	    //  printf("common ancestor %s %d %d\n", terms[ca]->get_goid(), terms[ca]->get_num_prot(), n_type[ot]);
	    if (min ==0 || np1 ==0 ||np2 ==0 ) return 0;
	    double minf = (double) min;
	    double ica= -log(minf/n_type[ot]);

	    //  if (id1 ==id2){ printf("%f %d %f %f \n", minf, n_type[ot], 1- minf/n_type[ot]);}
	    return (double)  2*ica * (1- minf/n_type[ot] ) /(term_information(id1) + term_information(id2) );
	  }
	  double semantic_similarity_lin(long id1, long id2)//***+
	  {
	    double ica = semantic_similarity_resnik(id1, id2);
	    long np1 = terms[id1]->get_num_prot();
	    long np2 = terms[id2]->get_num_prot();
	    if (ica ==0 || np1 ==0 ||np2 ==0 ) return 0;
	    return (double) 2*ica / (term_information(id1) + term_information(id2));
	  }
	  double semantic_similarity_wang(long id1, long id2)//***+
	  {
	    if (id1 == id2) return 1;
	    long ot = terms[id1]->get_ont_type();
	    long na1, na2;
	    na1 = terms[id1]->get_num_ancestor();
	    na2 = terms[id2]->get_num_ancestor();
	    double sum = 0;
	    for(long ii=0; ii!= na1; ++ii)
	      for(long jj=0; jj!= na2; ++jj)
	        if (terms[id1]->get_ancestor(ii) == terms[id2]->get_ancestor(jj))
	  	sum += terms[id1]->get_ancestor_score(ii) + terms[id2]->get_ancestor_score(jj);

	    return sum/(terms[id1]->get_semantic_value() + terms[id2]->get_semantic_value());
	  }
	  double term_information(long i)//***+
	  {
	    long ot = terms[i]->get_ont_type();
	    double np = (double) terms[i]->get_num_prot();
	    return - log (np/n_type[ot]);
	  }

	  long   validate_goid(char *st)//***+
	  {
	    if (st[0] == 'G' && st[1] == 'O' && st[2] == ':') return 1;
	    else return -1;
	  }
	  long   get_ont_type(char *st)//***+
	  {
	    if (strcmp(st, "molecular_function") ==0) return MF;
	    if (strcmp(st, "cellular_component") ==0) return CC;
	    if (strcmp(st, "biological_process") ==0) return BP;
	    return -1;
	  }
	  void  induce_all_ancestors(long id)//***+
	  {

	    if (mark[id] ==1)
	      return; // this term has been visited and updated

	    terms[id]->add_ancestor(terms[id]->get_id());

	    long n_parent = terms[id]->get_num_parents();

	    if (n_parent ==0)
	      {
	        mark[id] =1;
	        return;
	      }

	    for(long i = 0; i!= n_parent; ++i)
	      {
	        long parent = terms[id]->get_parent(i);
	        terms[id]->add_ancestor(parent);
	        induce_all_ancestors(parent); // truy ho^`i

	        long npp = terms[parent]->get_num_ancestor();

	        for(long j = 0; j!= npp; ++j)
	  	  terms[id]->add_ancestor(terms[parent]->get_ancestor(j));

	      }
	    mark[id] = 1;
	  }
	  //void  err()  {    printf("error reading file\n");    exit(0);   }


	  double function_similarity_max(VLong ids1, VLong ids2)//***+
	  {
	    double max = -1;
	    for(long i = 0; i!= ids1.size(); ++i)
	      for(long j = 0; j!= ids2.size(); ++j)
	        {
	  	double sim = get_sem_sim(ids1[i], ids2[j]);
	  	if (sim > max) max = sim;
	        }
	    return max;
	  }

	  double function_similarity_average(VLong ids1, VLong ids2)//***+
	  {
	    long count = 0;
	    double sum = 0;
	    for(long i = 0; i!= ids1.size(); ++i)
	      for(long j = 0; j!= ids2.size(); ++j)
	        {
	  	double sim = get_sem_sim(ids1[i], ids2[j]);
	  	if (sim >=0)
	  	  {
	  	    sum+= sim;
	  	    count++;
	  	  }
	        }
	    return sum/count;
	  }

	  double  GOScore(VLong ids1, VLong ids2)//***+
	  {
	    //max (rowScore, columnScore) ; rowScore = 1/n sum(max in row), columnScore = 1/m sum(max in column);
	    if (ids1.size() ==0 || ids2.size() ==0) return 0;

	    double sumMaxRow = 0;
	    long count = 0;
	    for(long i = 0; i!= ids1.size(); ++i)
	      {
	        double maxRow = -1;

	        for(long j = 0; j!= ids2.size(); ++j)
	  	{
	  	  double sim = get_sem_sim(ids1[i], ids2[j]);
	  	  if (sim >1)
	  	    exit(0);
	  	  if (sim > maxRow) maxRow = sim;
	  	}
	        if (maxRow >=0)
	  	{
	  	  sumMaxRow += maxRow;
	  	  count ++;
	  	}
	      }

	    if (count >0)
	      {
	        sumMaxRow = sumMaxRow/count;
	      }
	    else sumMaxRow = -1;

	    double sumMaxCol = 0;
	    count = 0;
	    for(long i = 0; i!= ids2.size(); ++i)
	      {
	        double maxCol = -1;
	        for(long j = 0; j!= ids1.size(); ++j)
	  	{
	  	  double sim = get_sem_sim(ids2[i], ids1[j]);
	  	  if (sim > maxCol) maxCol = sim;
	  	}
	        if (maxCol >=0)
	  	{
	  	  sumMaxCol += maxCol;
	  	  count ++;
	  	}
	      }

	    if (count >0)
	      {
	        sumMaxCol = sumMaxCol/count;
	        if (sumMaxCol >1) printf("maxCol %f\n", sumMaxCol);
	      }
	    else sumMaxCol = -1;

	    if (sumMaxCol> sumMaxRow) return sumMaxCol;
	    else return sumMaxRow;
	  }
	  double function_similarity_schlicker(VLong ids1, VLong ids2)//***+
	  {
	    double *x = function_similarity_schlicker_vec(ids1, ids2);
	    double out = sqrt(x[MF] *x[MF] + x[BP]*x[BP])/sqrt(2);
	    free(x);
	    return out;
	  }
	  //list of go_terms are from the same ontology, usually molecular function, does not accept those ffrom different ontologies
	  double function_similarity_wang(VLong ids1, VLong ids2)//***+
	  {
	    double sumMaxRow = 0;
	    for(long i = 0; i!= ids1.size(); ++i)
	      {
	        double maxRow = 0;
	        for(long j = 0; j!= ids2.size(); ++j)
	  	{
	  	  double sim = get_sem_sim(ids1[i], ids2[j]);
	  	  if (sim > maxRow) maxRow = sim;
	  	}
	        sumMaxRow += maxRow;
	      }

	    double sumMaxCol = 0;
	    for(long i = 0; i!= ids2.size(); ++i)
	      {
	        double maxCol = 0;
	        for(long j = 0; j!= ids1.size(); ++j)
	  	{
	  	  double sim = get_sem_sim(ids2[i], ids1[j]);
	  	  if (sim > maxCol) maxCol = sim;
	  	}
	        sumMaxCol += maxCol;
	      }
	    return (sumMaxRow + sumMaxCol)/(ids1.size() + ids2.size());
	  }
	  //long   get_index(long i, long j) { if (i >j) return i * (i+1)/2 + j ;
	  //  else return j * (j+1)/2 +i;}


	 public:
	  COntology_RW()
	 {
	   long MaxNumTerm = 50000;
	   terms = (CGOTerm_RW **) calloc(MaxNumTerm, sizeof(CGOTerm_RW*));

	   n_terms = 0;
	   n_type[0] =n_type[1]=n_type[2] = 0;
	   w1 = 0.8 ;//for is-a relationship
	   w2 = 0.6 ;//for part-of relationship
	 }
	  ~COntology_RW()
	  {
	    for(long i = 0; i!= n_terms; ++i)
	      if (terms[i] != NULL) delete terms[i];
	    free(terms);
	  }
	  long get_n_terms(){return n_terms;}
	  //get semantic similarity of 2 terms i and j from either an array of similarity score or from a file
	  double get_sem_sim(long i, long j)//***+
	  {
	        return semantic_similarity(i, j, RELEVANCE);
	  }

	  //long get_n_terms(){return n_terms;}
	  void read_go_ids(FILE *f)//***++
	  {
	    //  printf("ok here\n");
	    long buff_size = 10240;//le maximum nbre de chaine de charctere à copier dans buffer
	    char buffer[buff_size];// un tableau de chaine de charctére à copier
	    char goiid[15];
	    long obsolete = 0;
	    long ont_type;
	    long count = 0;
	    char namex[1024];

	    while(!feof(f))
	      {
	        fgets(buffer, buff_size, f);//get string from stream
	        //cout<<buffer<<endl;

	        char st1[128], st2[128], st3[128];
	        sscanf(buffer, "%s", st1);//read formated data from string, "%s": lire une chaine de charactere jusqu'a trouver un espace
	        //cout<<st1<<endl;
	        //cout<<"********"<<endl;
	        if (strstr(st1, "is_obsolete") != NULL)
	  	{
	  	  obsolete = 1;
	  	}
	        if (strcmp(st1, "[Term]")==0)
	  	{
	  	  //add old term
	  	  if (count >0 && obsolete ==0)
	  	    {
	  	      Trie.Add(goiid);
	  	      if (n_terms  == Trie.Size()) break;  // move on if goid already exists
	  	      terms[n_terms]= new CGOTerm_RW;
	  	      if (namex[strlen(namex)-1] == '\n') namex[strlen(namex) -1] = '\0';
	  	      terms[n_terms]->init_goterm(n_terms, goiid, namex, ont_type);
	  	      n_terms++;
	  	    }
	  	  count++;
	  	  obsolete = 0;
	  	  //read new term: get GO id
	  	  //cout<<"read new term: get GO id"<<endl;
	  	  fgets(buffer, buff_size, f);
	  	  //cout<<buffer<<endl;
	  	  sscanf(buffer, "%s %s", st2, st3);
	  	  //cout<<"st2: "<<st2<<"-"<<"st3: "<<st3<<endl;
	  	  if (strcmp(st2, "id:") != 0) break;
	  	  if (validate_goid(st3) == -1) break; //move on if not a goid
	  	  strcpy(goiid, st3);
	  	  //cout<<"goiid: "<<goiid<<endl;

	  	  //get ontology type
	  	  //cout<<"get ontology type"<<endl;
	  	  fgets(buffer, buff_size, f);
	  	  //cout<<buffer<<endl;
	  	  sscanf(buffer, "%s %s", st2, st3);
	  	  //cout<<"st2: "<<st2<<"-"<<"st3: "<<st3<<endl;
	  	  if (strcmp(st2, "name:") ==0)
	  	    {
	  	      char *p = buffer;
	  	      p += 6;
	  	      strcpy(namex, p);
	  	      //cout<<"namex: "<<namex<<endl;
	  	    }
	  	  if (strcmp(st2, "namespace:") ==0) ont_type = get_ont_type(st3);
	  	  else
	  	    {
	  	      fgets(buffer, buff_size, f);
	  	      //cout<<buffer<<endl;
	  	      sscanf(buffer, "%s %s", st2, st3);
	  	    //cout<<"st2: "<<st2<<"-"<<"st3: "<<st3<<endl;
	  	      if (strcmp(st2, "namespace:") ==0) ont_type = get_ont_type(st3);
	  	    }
	  	}
	      }
	    roots[BP] = Trie.Search("GO:0008150"); //biological process root
	    roots[MF] = Trie.Search("GO:0003674"); //moleculuar root
	    roots[CC] = Trie.Search("GO:0005575"); //cellular componenet root
	    //  printf("n term = %d\n", n_terms);
	  }
	  void read_go_ids(char *fn)//***++
	  {

	    FILE *f = fopen(fn, "r");

	    read_go_ids(f);
	    fclose(f);
	  }
	  void read_relations(FILE *f)//***++
	  {
	    long buff_size = 1024;
	    char buffer[buff_size];
	    //  printf("Trie size %d\n", Trie.Size());
	    while(!feof(f))
	      {
	        fgets(buffer, buff_size, f);
	        //cout<<buffer<<endl;
	        char st1[128], st2[128], st3[128], st4[128];
	        sscanf(buffer, "%s %s", st1, st2);
	        //cout<<"st1: "<<st1<<" st2: "<<st2<<endl;

	        // [Term] is the sign of starting of a new term. Other than that, just read through and skip
	        if (strcmp(st1, "[Term]")==0)
	  	{
	  	  fgets(buffer, buff_size, f); //Read next line to get GO ID
	  	  //cout<<buffer<<endl;
	  	  sscanf(buffer, "%s %s", st2, st3);
	  	//cout<<"st2: "<<st2<<" st3: "<<st3<<endl;
	  	  if (strcmp(st2, "id:") != 0) break;
	  	  if (validate_goid(st3) == -1) break; //move on if not a goid
	  	  long id = Trie.Search(st3);
	  	  if (id <0) continue;  //move on if goid not exists in the list (i.e., list imported before reading this file)


	  	  while (strlen(buffer) > 1)
	  	    {
	  	      long parent ;
	  	      fgets(buffer, buff_size, f);
	  	      //cout<<buffer<<endl;
	  	      sscanf(buffer, "%s %s %s", st2, st3, st4);
	  	    //cout<<"st2: "<<st2<<" st3: "<<st3<<" st4: "<<st4<<endl;

	  	      if (strcmp(st2, "is_a:") ==0)
	  		{
	  		  parent = Trie.Search(st3);
	  		  //cout<<"parent: "<<parent<<endl;
	  		  if (parent >=0)
	  		    {
	  		      terms[id]->add_parent(parent, ISA);
	  		      terms[parent]->add_child(id, ISA);
	  		    }
	  		}
	  	      if (strcmp(st2, "relationship:") ==0)
	  		{
	  		  parent = Trie.Search(st4);
	  		  if (parent >=0)
	  		    {
	  		      terms[id]->add_parent(parent, PARTOF);
	  		      terms[parent]->add_child(id, PARTOF);
	  		    }
	  		}

	  	    }
	  	}

	      }
	    for(long i = 0; i!= n_terms; ++i)
	      mark.push_back(0);

	    for(long i = 0; i!= n_terms; ++i)
	      induce_all_ancestors(i);
	  }
	  void read_relations(char *fn)//***++
	  {
	    FILE *f = fopen(fn, "r");
	    read_relations(f);
	    fclose(f);
	  }
	  //the list of ancestors of a node contains itself
	  void add_association(long id, long prot)//***++// prot=id de la proteine/ id id de terme
	  {
	    long np = terms[id]->get_num_ancestor();
	    for(long i = 0; i!= np; ++i)
	      {
	        long ancestor = terms[id]->get_ancestor(i);
	        terms[ancestor]->add_annotation(prot);
	      }
	  }
	  void add_protein_associations(FILE *f)//***++
	  {
	    long buff_size = 3000;
	    char buffer[buff_size], previous_prot[128], new_protein[128], st1[128], st2[128], st3[128], st4[128], st5[128];
	    char *p1, *p2;
	    long mark[3];
	    long iid, ot; //temporary variable

	    n_protein = 0;
	    strcpy(previous_prot, "");
	    mark[CC] = 0; mark[BP]=0; mark[MF] = 0;
	    fgets(buffer, buff_size, f);
	    while(!feof(f))
	      {
	        fgets(buffer, buff_size, f);
	        sscanf(buffer, "%s %s %s %s %s", st1, st2, st3, st4, st5);
	        p1 = NULL;
	        p2 = NULL;
	        p1 = strstr(st4, "GO:");
	        p2 = strstr(st5, "GO:");
	        if (p1 != NULL)
	  	  iid= Trie.Search(st4);
	        else if (p2 != NULL)
	  	iid= Trie.Search(st5);

	        p1 = strstr(st4, "NOT");

	        if (p1 != NULL)  continue;
	        if (iid <0) continue;
	        //CHECK HERE
	        strcpy(new_protein, st2);
	        ot = terms[iid]->get_ont_type();

	        if (strcmp(new_protein, previous_prot) !=0)
	  	{
	  	  strcpy(previous_prot, new_protein);
	  	  n_protein++;
	  	  mark[CC] = 0; mark[BP]=0; mark[MF] = 0;
	  	  if (n_protein % 5000 ==0) printf("%s %d\n", st2, n_protein);
	  	}

	        if (mark[ot] ==0)
	  	{
	  	  n_type[ot] ++;
	  	  mark[ot] = 1;
	  	}

	        add_association(iid, n_protein);
	      }
	    /**
	    for(long i = 0; i!= 3; ++i)
	      {
	        printf("Check point: n_protein %d,  n_prot at root %d \n", n_type[i], terms[roots[i]]->get_num_prot(), i );
	      }

	    */
	  }
	  void add_protein_associations(char *fn)//***++
	  {
	    FILE *f = fopen(fn, "r");
	    add_protein_associations(f);
	    fclose(f);
	  }

	  //void add_protein_associations2(char *fn);
	  void add_protein_associations(FILE *f, CTrieTree* proteins)//***++
	  {
	    long buff_size = 3000;
	    char buffer[buff_size], previous_prot[128], new_protein[128], st1[128], st2[128], st3[128], st4[128], st5[128];
	    long mark[3], iid, prot, ot;
	    char *p1, *p2;

	    mark[CC] = 0; mark[BP]=0; mark[MF] = 0;
	    n_protein = 0;
	    strcpy(previous_prot, "");

	    while(!feof(f))
	      {
	        fgets(buffer, buff_size, f);
	        //cout<<"buffer: "<<buffer<<endl;
	        sscanf(buffer, "%s %s %s %s %s", st1, st2, st3, st4, st5);
	        //cout<<"st1: "<<st1<<" st2: "<<st2<<" st3: "<<st3<<" st4: "<<st4<<" st5: "<<st5<<endl;
	        p1 = NULL;
	        p2 = NULL;
	        p1 = strstr(st4, "GO:");
	       // //cout<<"p1: "<<p1<<endl;
	        p2 = strstr(st5, "GO:");
	        ////cout<<"p2: "<<p2<<endl;
	        if (p1 != NULL)	iid= Trie.Search(st4);
	        else if (p2 != NULL) iid= Trie.Search(st5);
	        ////cout<<"iid: "<<iid<<endl;
	        p1 =strstr(st4, "NOT");

	        if (  p1!= NULL)  continue;
	        if (iid <0) continue;
	        prot = proteins->Search(st2);
	       // //cout<<"pro: "<<prot<<endl;
	        if (prot <0) continue;

	        strcpy(new_protein, st2);
	       // //cout<<"new_protein: "<<new_protein<<endl;
	        ot = terms[iid]->get_ont_type();
          //  //cout<<"ot: "<<ot<<endl;

	        if (strcmp(new_protein, previous_prot) !=0)
	  	{
	  	  strcpy(previous_prot, new_protein);
	  	  mark[CC] = 0; mark[BP]=0; mark[MF] = 0;
	  	  n_protein ++;
	  	}

	        if (mark[ot] ==0) {n_type[ot] ++; mark[ot] = 1;}

	        add_association(iid, prot);
	      }
	    /**
	    for(long i = 0; i!= 3; ++i)
	      {
	        printf("Check point: n_protein %d,  n_prot at root %d \n", n_type[i], terms[roots[i]]->get_num_prot(), i );
	      }

	    */
	  }
	  void add_protein_associations(char *fn, CTrieTree* proteins)//***++
	  {
	    FILE *f = fopen(fn, "r");
	    add_protein_associations(f, proteins);
	    fclose(f);
	  }
	 // void add_protein_associations1(char *fn, CTrieTree *);
	  //void add_protein_associations2(char *fn, CTrieTree *);
	  //void add_term_frequency(char *fn);
	  //void add_term_frequency(FILE *f);
	  //void print_frequency(char *fn);

	  double semantic_similarity(long id1, long id2, long option)//***+
	  {
	    long ot1, ot2;
	    ot1 = terms[id1]->get_ont_type();
	    ot2 = terms[id2]->get_ont_type();

	    if (ot1 != ot2) return -1;

	    if (option == RESNIK) return semantic_similarity_resnik(id1, id2);
	    if (option == LIN)    return semantic_similarity_lin(id1, id2);
	    if (option == JIANG)  return semantic_similarity_jiang(id1, id2);
	    if (option == RELEVANCE) return semantic_similarity_relevance(id1, id2);
	    if (option == WANG) return semantic_similarity_wang(id1, id2);
	  }

	 // double semantic_similarity(char *goid1, char *goid2, long option);  //if 2 terms are from different ontologies, the distance is set to -1
	  //double function_similarity(char **, long size1, char **, long size2, long opt);
	  double function_similarity(VLong ids1,  VLong ids2, long option)//***+
	  {
	    if (ids1.size() ==0 || ids2.size() ==0) return 0;
	    if (option == MAX)     return   function_similarity_max(ids1,  ids2);
	    if (option == AVERAGE)  return   function_similarity_average(ids1, ids2);
	    if (option == SCHLICKER)  return  function_similarity_schlicker(ids1, ids2);
	    if (option == WANG2)  return  function_similarity_wang(ids1, ids2);

	  }

	  double *function_similarity_schlicker_vec(VLong ids1, VLong ids2)//***+
	  {

	    double *out = (double*)calloc(3, sizeof(double));
	    VVLong gos1, gos2;
	    long  size_gos1[3], size_gos2[3];

	    for(long i=0; i!= 3; ++i)
	      {
	        VLong temp;
	        gos1.push_back(temp);
	        gos2.push_back(temp);
	      }

	    for(long i =0; i!= ids1.size(); ++i)
	      {
	        long ot = terms[ids1[i]] ->get_ont_type() ;
	        gos1[ot].push_back(ids1[i]);
	      }
	    for(long i =0; i!= ids2.size(); ++i)
	      {
	        long ot = terms[ids2[i]] ->get_ont_type() ;
	        gos2[ot].push_back(ids2[i]);
	      }
	    out[MF] = GOScore(gos1[MF], gos2[MF]);
	    out[BP] = GOScore(gos1[BP], gos2[BP]);
	    out[CC] = GOScore(gos1[CC], gos2[CC]);

	    return out;
	  }

	  //void calculate_semantic_similarities(long option);
	 // double get_semantic_similarity(char *, char*);

	  //for other program to access
	  long Search(char *goterm) {return Trie.Search(goterm);};//***
	  //char *get_goterm(long goid) {return terms[goid]->get_goid();}
	  //char *get_goterm_name(long goid) {return terms[goid]->get_name();}
	  //long get_ont_type(long goid) {return terms[goid]->get_ont_type();}
	  VLong get_ancestors(long goid) {return terms[goid]->get_ancestors();}//***
	  //long get_n_prot(long goid){return terms[goid]->get_num_prot();};
	  //long get_n_proteins(){return n_protein;};
	  //long get_n_proteins(long ont_type){return n_type[ont_type];};
	  //VLong get_assoc_prots(long goid){return terms[goid]->get_prots();}
	  //VLong get_parents(long goid) {return terms[goid]->get_parents();}
	  //VLong get_children(long goid) {return terms[goid]->get_children();}

	  void update_protein_count(long goid, long count){terms[goid]->update_protein_count(count);}

	  //VLong get_to_second_level();

};
































#endif /* GO_SIM_H_ */
