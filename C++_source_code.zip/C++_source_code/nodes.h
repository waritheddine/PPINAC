//s
#ifndef NODES_H_
#define NODES_H_

#define MaxLen 128
#define MaxLenBuffer 1024*10


#include"go_sim.h"
#include "TrieTree.h"

class CNode{
  char label[100]; //TODO
  long  index;
  VLong goids;
 public:
  CNode()
    {
    };
  ~CNode()
    {
    };

  void SetupNode(char *s, long id)   { strcpy(label, s); index = id;}//***
  char* GetLabel() {return label;}//***
  long  GetIndex(){return index;}
  VLong get_goids(){return goids;}//***
  void add_goid(long goid) //***
  {

	  for(long i =0; i!= goids.size(); ++i)
	    if (goids[i] == goid) return;
	  goids.push_back(goid);

  }
  void add_goid1(long goid, COntology_RW *ontology)//***
  {


	  VLong gos = ontology->get_ancestors(goid);

	  for(long k=0; k!= gos.size(); ++k)
	    {
	      for(long l = 0; l!= goids.size(); ++l)
	        if (gos[k] == goids[l])
	 	 {
	 	   replace_goid(goid, l);
	 	   return;
	 	 }
	    }

	  add_goid(goid);
	  return;

  }
  void add_goid2(long goid, COntology_RW *ontology)//***
  {


	  VLong gos = ontology->get_ancestors(goid);

	  for(long k=0; k!= gos.size(); ++k)
	    add_goid(gos[k]);

	  add_goid(goid);
	  return;

  }
  void replace_goid(long goid, long id)//***
  {

	  goids[id] = goid;

  }
};


class CNodes
{
 protected:
  CNode **nodes;
  long n;
  CTrieTree Trie;
  long inc;
  long mode; // association of GO terms read in mode,  =0: add only bottom line terms, =1 add all ancestors
 public:
 // CNodes(long Inc) ;

  //CNodes();
  //~CNodes();

  CNodes(long M)
  {
    mode = M; //mode when get association GO terms : =0 : add only those at the bottom, =1 add all ancestors of the term
    n = 0;
  }

  CNodes()
  {

    mode = 0;
    nodes = NULL;
    n = 0;
  }

  ~CNodes()
  {
    for(long i = 0; i != n; ++i)
     if (nodes[i] != NULL) delete nodes[i];
    if (nodes!= NULL)  {free(nodes); nodes = NULL;}

  }



  long   Search(char *s) {return Trie.Search(s);}//***
  CNode* SearchNode(char* s)
    {
      int id = Trie.Search(s);
      if (id <0) return NULL;
      else return nodes[id];
    }
  long   Add(char *lab)//***
  {

	  long id = Search(lab);
	  if (id > -1) return id ;

	  Trie.Add(lab); //Add new label to TrieTree

	 //Add new node to nodes

	  n++;
	  nodes = (CNode**) realloc(nodes, n* sizeof(CNode*));

	  nodes[n-1] = new CNode;
	  nodes[n-1]->SetupNode(lab, n-1);
	  return (n-1);

  }
  long   GetNumNodes(){return n;}
  CNode *GetNode(long id){return nodes[id];}
  void  Print(FILE *f);
  char *GetLabel(long i) {nodes[i]->GetLabel();}//***
  void  Read(FILE *f)  //read of a list of nodes
  {

	  char temps[1024];
	  while(!feof(f))
	    {
	      fscanf(f, "%s", temps);
	      Add(temps);
	    }

  }
  void  Read(char *fn)
  {
    FILE *f = fopen(fn, "r");
    Read(f);
    fclose(f);
  } //read of a list of nodes

  void  ReadFromGraph(FILE *f) //read of a list of nodes
  {

	  char st1[1024], st2[1024];
	  while(!feof(f))
	    {
	      fscanf(f, "%s %s", st1, st2);
	      Add(st1);
	      Add(st2);
	      fgets(st1, 1024, f);
	    }

  }
  void  ReadFromGraph(char *fn)
  {
    FILE *f = fopen(fn, "r");
    ReadFromGraph(f);
    fclose(f);
  } //read of a list of nodes

  CTrieTree *get_trie(){return &Trie;};//***

  void add_gene_associations(FILE *f, COntology_RW *ontology)
  {


	  long size_buff = 50000;
	  char buffer[size_buff];
	  char st1[128], st2[128], st3[128], st4[128], st5[128];
	  while (!feof(f))
	    {
	      fgets(buffer, size_buff, f);
	      //cout<<buffer<<endl;
	      sscanf(buffer, "%s %s %s %s %s", st1, st2, st3, st4, st5);
	      //cout<<"st1: "<<st1<<"st2: "<<st2<<"st3: "<<st3<<"st4: "<<st4<<endl;
	      long node_id = Trie.Search(st2);
	      if (node_id <0) continue;

	      //st4 can either be the GO term itself or the qualifier of the GO term, which can be
	      //"NOT", "colocolizes_with", "contributes_to"
	      long goid;
	      if (strstr(st4, "GO:") != NULL)
		  goid= ontology->Search(st4);
	      else if (strstr(st5, "GO:") != NULL)
		goid= ontology->Search(st5);

	      if (strcmp(st4, "NOT") ==0) continue;
	      if (goid <0) continue;

	      if (mode ==0)
		nodes[node_id]->add_goid1(goid, ontology);
	      if (mode ==1)
		nodes[node_id]->add_goid2(goid, ontology);
	      continue;
	    }

  }
  void add_gene_associations1(FILE *f, COntology_RW *ontology)
  {


	  long size_buff = 50000;
	  char buffer[size_buff];
	  char st1[128], st2[128], st3[128], st4[128], st5[128];
	  while (!feof(f))
	    {
	      fgets(buffer, size_buff, f);
	      sscanf(buffer, "%s %s %s %s", st1, st2, st3, st4);
	      long node_id = Trie.Search(st2);
	      if (node_id <0) continue;

	      //st4 can either be the GO term itself or the qualifier of the GO term, which can be
	      //"NOT", "colocolizes_with", "contributes_to"
	      long goid;
	      if (strstr(st3, "GO:") != NULL)
		  goid= ontology->Search(st3);
	      else if (strstr(st4, "GO:") != NULL)
		goid= ontology->Search(st3);

	      if (goid <0) continue;

	      if (mode ==0)
		nodes[node_id]->add_goid1(goid, ontology);
	      if (mode ==1)
		nodes[node_id]->add_goid2(goid, ontology);
	      continue;
	    }

  }
  void add_gene_associations_isoform(FILE *f, COntology_RW *ontology)//***
  {

	  long size_buff = 50000;
	  char buffer[size_buff];
	  char st1[128], st2[128], st3[128], st4[128], st5[128];
	  char *p1, *p2;
	  long goid, node_id;

	  while (!feof(f))
	    {
	      fgets(buffer, size_buff, f);
	      //cout<<"buffer: "<< buffer<<endl;
	      sscanf(buffer, "%s %s %s %s", st1, st2, st3, st4);
	      //cout<<"st1: "<<st1<<" st2: "<<st2<<" st3: "<<st3<<" st4: "<<st4<<endl;
	      p1 = p2 =  NULL;
	      p1 = strstr(st4, "GO:");
	      p2 = strstr(st5, "GO:");

	      if ( p1 != NULL)	  goid= ontology->Search(st4);
	      else
		if (p2!= NULL)	goid= ontology->Search(st5);

	      p1 = strstr(st4, "NOT");
	      if (p1  != NULL)  continue;
	      if (goid <0) continue;

	      node_id = Trie.Search(st2);
	      if (node_id >= 0)
		{
		  if (mode ==0)   nodes[node_id]->add_goid1(goid, ontology);
		  if (mode ==1)   nodes[node_id]->add_goid2(goid, ontology);
		}
	      for(long i =0; i!= 20; ++i)
		{
		  char temps[128];
		  sprintf(temps, "%s-%d", st2, i);
		  //cout<<"temps: "<<temps<<endl;
		  node_id = Trie.Search(temps);
		  //	  printf("%s\t%d\n", temps, node_id);
		  if (node_id >=0)
		    {
		      if (mode ==0)
			nodes[node_id]->add_goid1(goid, ontology);
		      if (mode ==1)
			nodes[node_id]->add_goid2(goid, ontology);
		    }

		}


	    }

  }

  void add_goid(long id, long goid) {nodes[id]->add_goid(goid);}
  void add_goid(long id, long goid, COntology_RW *ontology)
  {
    nodes[id]->add_goid2(goid, ontology);
  }

  VLong get_goids_from_node(long id)//***
  {

	  return nodes[id]->get_goids();

  }
  VLong get_associated_prots(long goid)
  {

	  VLong temp;
	  for(long i =0; i!= n; ++i)
	    {

	      VLong goids = get_goids_from_node(i);
	      for(long j=0; j!= goids.size(); ++j)
		if (goids[j] == goid)
		  {
		    temp.push_back(i);
		    break;
		  }
	    }
	  return temp;

  }
  void change_assoc_mode(long m) {mode =m;}
  void update_ontology_protein_count(COntology_RW *ontology)
  {

	  long nterms = ontology->get_n_terms();
	  for(long k=0; k!= nterms; ++k)
	    {
	      long count =0;
	      for(long i =0; i!= n; ++i)
		{

		  VLong goids = get_goids_from_node(i);
		  for(long j=0; j!= goids.size(); ++j)
		    if (goids[j] == k)
		      {
			count++;
			break;
		      }
		}
	      ontology->update_protein_count(k, count);
	    }


  }
};




#endif
